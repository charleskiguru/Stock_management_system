﻿namespace STOCK__MANAGEMENT_SYSTEM
{
    internal class PdfTable
    {
    }
}