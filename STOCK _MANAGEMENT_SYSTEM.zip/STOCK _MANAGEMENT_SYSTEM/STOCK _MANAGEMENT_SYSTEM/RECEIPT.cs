﻿using STOCK__MANAGEMENT_SYSTEM.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace STOCK__MANAGEMENT_SYSTEM
{
    public partial class RECEIPT : Form
    {
        static string conString = "server=localhost;database=storedb;Uid=root;Pwd=;";
        MySqlConnection con = new MySqlConnection(conString);
        MySqlCommand cmd;
        MySqlDataReader dr;
        MySqlDataAdapter adapter;
        public RECEIPT()
        {
            InitializeComponent();
            fill_combo();
            

        }

        private void fill_combo()
        {
            try
            {
                con.Open();
                string Query = "SELECT * FROM store ORDER BY proname ASC";
               
                cmd = new MySqlCommand(Query, con);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    string proname = dr.GetString(1);
                    ItemnamecomboBox.Items.Add(proname);

                }
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }
        private List<models.CartItem> shoppingCart = new List<models.CartItem>();
        private object Resources;

        private void NewOrderbutton_Click(object sender, EventArgs e)
        {
            NewOrderbutton.Enabled = false;
            PrintOrderbutton.Enabled = true;
            PrintPreviewbutton.Enabled = true;
            CancelOrderbutton.Enabled = true;
            dateTimePicker1.Enabled = false;

            ItemgroupBox.Enabled = true;
            clientnametextBox.Focus();
        }

        private void CancelOrderbutton_Click(object sender, EventArgs e)
        {
            NewOrderbutton.Enabled = true;
            PrintOrderbutton.Enabled = false;
            PrintPreviewbutton.Enabled = false;
            CancelOrderbutton.Enabled = false;
          

            ItemgroupBox.Enabled = false;

            clientnametextBox.Clear();
            ItemnamecomboBox.SelectedIndex = -1;
            QuantitytextBox.Clear();
            UnitpricetextBox.Clear();
            textBoxQtySale.Clear();


            TotalAmounttextBox.Text = "0";
            SalesTaxtextBox.Text = "0";
            TotalToPaytextBox.Text = "0";

            CartdataGridView.DataSource = null;
            shoppingCart.Clear();
        }

        private void AddTocartbutton_Click(object sender, EventArgs e)
        {
            

            if (IsValidated())
            {
                models.CartItem item = new models.CartItem()
                {
                    ItemName = ItemnamecomboBox.Text,
                    Quantity = Convert.ToInt16(QuantitytextBox.Text.Trim()),
                    UnitPrice = Convert.ToDecimal(UnitpricetextBox.Text.Trim()),
                    Totalprice = Convert.ToInt16(QuantitytextBox.Text.Trim()) * Convert.ToDecimal(UnitpricetextBox.Text.Trim())

                };
                shoppingCart.Add(item);


                CartdataGridView.DataSource = null;
                CartdataGridView.DataSource = shoppingCart;



                decimal totalAmount = shoppingCart.Sum(x => x.Totalprice);
                TotalAmounttextBox.Text = totalAmount.ToString();

                decimal totalsalestax = (16 * totalAmount) / 100;
                SalesTaxtextBox.Text = totalsalestax.ToString();

                decimal TotaltoPay = totalAmount + totalsalestax;
                TotalToPaytextBox.Text = TotaltoPay.ToString();

                ItemnamecomboBox.SelectedIndex = -1;
                QuantitytextBox.Clear();
                UnitpricetextBox.Clear();
                textBoxQtySale.Clear();
           }
        }

        private bool IsValidated()
        {

            if (clientnametextBox.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Client name is required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                clientnametextBox.Focus();
                return false;
            }
            if (ItemnamecomboBox.SelectedIndex == -1)
            {
                MessageBox.Show("Product name is required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (QuantitytextBox.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Quantity is required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                QuantitytextBox.Focus();
                return false;
            }
          else
            {

                int tempQuantity;
                bool IsNumeric = int.TryParse(QuantitytextBox.Text.Trim(), out tempQuantity);

                if (!IsNumeric)
                {
                    MessageBox.Show("Quantity should be value", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    QuantitytextBox.Clear();
                    QuantitytextBox.Focus();
                    return false;
                }
            }

            if (UnitpricetextBox.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Unit price is required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                UnitpricetextBox.Focus();
                return false;
            }
            else
            {

                decimal n;
                bool Isdecimal = decimal.TryParse(UnitpricetextBox.Text.Trim(), out n);

                if (!Isdecimal)
                {
                    MessageBox.Show("Unit price should be decimal  value", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    UnitpricetextBox.Clear();
                    UnitpricetextBox.Focus();
                    return false;
                }
            }
            try
            {
                int var1, var2 = 0;
                var1 = Convert.ToInt32(this.QuantitytextBox.Text);
                var2 = Convert.ToInt32(this.textBoxQtySale.Text);

                if (var1 <= var2)
                {
                   // MessageBox.Show("Add");

                }
                else
                {
                    MessageBox.Show("Quantity Purchased is above the available Stock!! ");
                    return false;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return true;
        }
         private void CartdataGridView_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                var hti = CartdataGridView.HitTest(e.X, e.Y);
                CartdataGridView.Rows[hti.RowIndex].Selected = true;

                contextMenuStrip1.Show(CartdataGridView, e.X, e.X);
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int index = CartdataGridView.CurrentCell.RowIndex;
            shoppingCart.RemoveAt(index);

            CartdataGridView.DataSource = null;
            CartdataGridView.DataSource = shoppingCart;


            decimal totalAmount = shoppingCart.Sum(x => x.Totalprice);
            TotalAmounttextBox.Text = totalAmount.ToString();

            decimal totalsalestax = (16 * totalAmount) / 100;
            SalesTaxtextBox.Text = totalsalestax.ToString();

            decimal TotaltoPay = totalAmount + totalsalestax;
            TotalToPaytextBox.Text = TotaltoPay.ToString();

        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("Date:" + DateTime.Now.ToShortDateString(), new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(35, 190));


            e.Graphics.DrawString("Client Name:   " + clientnametextBox.Text.Trim(), new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(35, 220));
            e.Graphics.DrawString(".......................................................................................................................................................................................",
                new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(25, 230));


            e.Graphics.DrawString("Item Name ", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(30, 255));
            e.Graphics.DrawString("Quantity  ", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(380, 255));
            e.Graphics.DrawString("Unit Price ", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(510, 255));
            e.Graphics.DrawString("Total Price ", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(660, 255));

            e.Graphics.DrawString(".......................................................................................................................................................................................",
               new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(25, 270));

            int yPos = 295;

            foreach (var i in shoppingCart)
            {

                e.Graphics.DrawString(i.ItemName, new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(30, yPos));
                e.Graphics.DrawString(i.Quantity.ToString(), new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(400, yPos));
                e.Graphics.DrawString(i.UnitPrice.ToString(), new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(525, yPos));
                e.Graphics.DrawString(i.Totalprice.ToString(), new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(675, yPos));

                yPos += 30;
            }
            e.Graphics.DrawString(".......................................................................................................................................................................................",
               new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(25, yPos));

            e.Graphics.DrawString("Total Amount  :   Ksh." + TotalAmounttextBox.Text.Trim(), new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(550, yPos + 30));
            e.Graphics.DrawString("Sales Tax(16%):   Ksh." + SalesTaxtextBox.Text.Trim(), new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(550, yPos + 60));
            e.Graphics.DrawString("Total To Pay  :   Ksh." + TotalToPaytextBox.Text.Trim(), new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(550, yPos + 90));
        }


        private void PrintPreviewbutton_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void PrintOrderbutton_Click(object sender, EventArgs e)
        {
            sales();
            update();
            printDocument1.Print();
            CancelOrderbutton_Click(sender, e);

        }
        private void update()
        {
            for (int i = 0; i < CartdataGridView.Rows.Count; i++)
            {
                cmd = new MySqlCommand(@"UPDATE store SET stock=stock- '" + CartdataGridView.Rows[i].Cells[1].Value.ToString() + "'WHERE proname='" + CartdataGridView.Rows[i].Cells[0].Value.ToString() + "'", con);
                con.Open();

                cmd.ExecuteNonQuery();

                con.Close();

            }
            }
        private void sales()
        {
            
            
            for (int i = 0; i < CartdataGridView.Rows.Count; i++)
            {
                cmd = new MySqlCommand(@"INSERT INTO report (Product_Name,Quantity_Sold,Unit_Price,Total_Price,TotalAmountPaid,Date_of_Sale) VALUES('" + CartdataGridView.Rows[i].Cells[0].Value.ToString() + "','" + CartdataGridView.Rows[i].Cells[1].Value.ToString() + "','" + CartdataGridView.Rows[i].Cells[2].Value.ToString() + "','" + CartdataGridView.Rows[i].Cells[3].Value.ToString() + "','"+ TotalToPaytextBox.Text+ "','" + dateTimePicker1.Text+"')", con);
                con.Open();
                cmd.ExecuteNonQuery();
                
                con.Close();
            }
            }
        private void ItemnamecomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string query = "SELECT * FROM store WHERE proname='" + ItemnamecomboBox.Text + "'";
                cmd = new MySqlCommand(query, con);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {

                    string price = dr.GetString("price");
                    string quantity = dr.GetString("stock");
                    UnitpricetextBox.Text = price;
                    textBoxQtySale.Text = quantity;
               

                }
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SELLbutton_Click(object sender, EventArgs e)
        {


            if (QuantitytextBox.Text == "" || UnitpricetextBox.Text == ""||clientnametextBox.Text==""||ItemnamecomboBox.Text=="")
            {
                MessageBox.Show("Item Name,Client Name,Quantity and Unit Price must be filled!!!!", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
            {


                string sql = "UPDATE store SET stock=stock-'" + this.QuantitytextBox.Text + "' WHERE proname='" + this.ItemnamecomboBox.Text + "' ";
                cmd = new MySqlCommand(sql, con);

                try
                {
                    con.Open();
                    adapter = new MySqlDataAdapter(cmd);
                    adapter.UpdateCommand = con.CreateCommand();
                    adapter.UpdateCommand.CommandText = sql;
                    if (MessageBox.Show("Are you sure you want sale?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        if (adapter.UpdateCommand.ExecuteNonQuery() > 0)
                        {
                           
                        }
                    }
                    con.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    con.Close();
                }
            }
        }

        private void QuantitytextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void QuantitytextBox_KeyPress(object sender, KeyPressEventArgs e)
        {

            char ch = e.KeyChar;

            if (!char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void UnitpricetextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (ch == 46 && QuantitytextBox.Text.IndexOf('.') != -1)
            {
                e.Handled = true;
                return;
            }
            if (!char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }
      
        private void buttonINSERT_Click(object sender, EventArgs e)
        {
            for(int i=0;i<CartdataGridView.Rows.Count; i++)
            {
                cmd = new MySqlCommand(@"INSERT INTO report(itemname,quantity,unitprice,totalprice) VALUES('" + CartdataGridView.Rows[i].Cells[0].Value.ToString()+"','"+ CartdataGridView.Rows[i].Cells[1].Value.ToString() + "','"+ CartdataGridView.Rows[i].Cells[2].Value.ToString() + "','"+ CartdataGridView.Rows[i].Cells[3].Value.ToString() + "')",con);
                con.Open();
                cmd.ExecuteNonQuery();

                con.Close();
               // MessageBox.Show("data saved");

            }
          //  CartdataGridView.Rows.Clear();
           
        }

        private void buttonCALC_Click(object sender, EventArgs e)
        {
            CALCULATOR obj = new CALCULATOR();
            obj.Show();

        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }
    }
}