﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace STOCK__MANAGEMENT_SYSTEM
{
    public partial class STOCK_REPORTS : Form
    {
        static string conString = "server=localhost;database=storedb;Uid=root;Pwd=;";
        MySqlConnection con = new MySqlConnection(conString);
        //MySqlCommand cmd;
       // MySqlDataReader dr;
        MySqlDataAdapter adapter;
        DataTable dt = new DataTable();
        public STOCK_REPORTS()
        {
            InitializeComponent();
            retrieve();
        }
        private void retrieve()
        {
            //DateTime datetime = DateTime.Now;
            //this.label5.Text = datetime.ToString();


            MySqlCommand cmd = new MySqlCommand("SELECT  id, proname,  stock ,price,date FROM store ", con);
            try
            {
                adapter = new MySqlDataAdapter(cmd);
                adapter.SelectCommand = cmd;
                dt = new DataTable();
                adapter.Fill(dt);

                BindingSource bs = new BindingSource();
                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
                adapter.Update(dt);


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void STOCK_REPORTS_Load(object sender, EventArgs e)
        {
            button1_Click(sender, e);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int total = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; ++i)
            {
                total +=( Convert.ToInt32(dataGridView1.Rows[i].Cells[2].Value) * Convert.ToInt32(dataGridView1.Rows[i].Cells[3].Value));
            }
            textBox1.Text = (total.ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {

            con.Open();
            adapter = new MySqlDataAdapter("select  id, proname,  stock ,price,date,Supplier_Id from store WHERE date between '" + dateTimePicker1.Text.ToString() + "' AND '" + dateTimePicker2.Text.ToString() + "'", con);
            DataSet ds = new DataSet();
            adapter.Fill(ds, "store");

         
            dataGridView1.DataSource = ds.Tables["store"];
        
            con.Close();
            button1_Click(sender, e);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            retrieve();
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            printDocument1.Print();
        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap bmp = new Bitmap(this.dataGridView1.Width, this.dataGridView1.Height);
            dataGridView1.DrawToBitmap(bmp, new System.Drawing.Rectangle(0, 0, this.dataGridView1.Width, this.dataGridView1.Height));
            e.Graphics.DrawImage(bmp, 0, 0);

            e.Graphics.DrawString("STOCK VALUE :   Ksh." + textBox1.Text.Trim(), new System.Drawing.Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(550, 550));

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

            DataView DV = new DataView(dt);

            DV.RowFilter = string.Format(" proname LIKE '%{0}'", textBox2.Text);

            dataGridView1.DataSource = DV;

            button1_Click(sender, e);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
