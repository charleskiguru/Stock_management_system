﻿namespace STOCK__MANAGEMENT_SYSTEM
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxPass = new System.Windows.Forms.TextBox();
            this.textboxUser = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnEXIT = new System.Windows.Forms.Button();
            this.BTNLogin = new System.Windows.Forms.Button();
            this.Btn_Clear = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.logincomboBox = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Algerian", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label2.Location = new System.Drawing.Point(109, 182);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 21);
            this.label2.TabIndex = 18;
            this.label2.Text = "Password";
            // 
            // textBoxPass
            // 
            this.textBoxPass.BackColor = System.Drawing.Color.White;
            this.textBoxPass.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPass.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBoxPass.Location = new System.Drawing.Point(301, 174);
            this.textBoxPass.Multiline = true;
            this.textBoxPass.Name = "textBoxPass";
            this.textBoxPass.PasswordChar = '.';
            this.textBoxPass.Size = new System.Drawing.Size(206, 29);
            this.textBoxPass.TabIndex = 17;
            this.textBoxPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textboxUser
            // 
            this.textboxUser.BackColor = System.Drawing.Color.White;
            this.textboxUser.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textboxUser.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textboxUser.Location = new System.Drawing.Point(301, 99);
            this.textboxUser.Multiline = true;
            this.textboxUser.Name = "textboxUser";
            this.textboxUser.Size = new System.Drawing.Size(206, 31);
            this.textboxUser.TabIndex = 16;
            this.textboxUser.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textboxUser.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textboxUser_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Algerian", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label1.Location = new System.Drawing.Point(109, 101);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 21);
            this.label1.TabIndex = 15;
            this.label1.Text = "UserName";
            // 
            // BtnEXIT
            // 
            this.BtnEXIT.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.BtnEXIT.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.BtnEXIT.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSkyBlue;
            this.BtnEXIT.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSkyBlue;
            this.BtnEXIT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnEXIT.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEXIT.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnEXIT.Location = new System.Drawing.Point(331, 307);
            this.BtnEXIT.Margin = new System.Windows.Forms.Padding(0);
            this.BtnEXIT.Name = "BtnEXIT";
            this.BtnEXIT.Size = new System.Drawing.Size(83, 36);
            this.BtnEXIT.TabIndex = 14;
            this.BtnEXIT.Text = "&EXIT";
            this.BtnEXIT.UseVisualStyleBackColor = false;
            this.BtnEXIT.Click += new System.EventHandler(this.BtnEXIT_Click);
            // 
            // BTNLogin
            // 
            this.BTNLogin.BackColor = System.Drawing.Color.White;
            this.BTNLogin.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.BTNLogin.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSkyBlue;
            this.BTNLogin.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSkyBlue;
            this.BTNLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNLogin.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNLogin.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BTNLogin.Location = new System.Drawing.Point(331, 225);
            this.BTNLogin.Margin = new System.Windows.Forms.Padding(0);
            this.BTNLogin.Name = "BTNLogin";
            this.BTNLogin.Size = new System.Drawing.Size(163, 36);
            this.BTNLogin.TabIndex = 13;
            this.BTNLogin.Text = "&LOGIN";
            this.BTNLogin.UseVisualStyleBackColor = false;
            this.BTNLogin.Click += new System.EventHandler(this.BTNLogin_Click);
            // 
            // Btn_Clear
            // 
            this.Btn_Clear.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.Btn_Clear.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.Btn_Clear.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSkyBlue;
            this.Btn_Clear.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSkyBlue;
            this.Btn_Clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Clear.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Clear.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Btn_Clear.Location = new System.Drawing.Point(472, 307);
            this.Btn_Clear.Margin = new System.Windows.Forms.Padding(0);
            this.Btn_Clear.Name = "Btn_Clear";
            this.Btn_Clear.Size = new System.Drawing.Size(83, 36);
            this.Btn_Clear.TabIndex = 19;
            this.Btn_Clear.Text = "&CLEAR";
            this.Btn_Clear.UseVisualStyleBackColor = false;
            this.Btn_Clear.Click += new System.EventHandler(this.Btn_Clear_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(665, 464);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 20);
            this.label4.TabIndex = 20;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.logincomboBox);
            this.panel1.Controls.Add(this.BtnEXIT);
            this.panel1.Controls.Add(this.Btn_Clear);
            this.panel1.Controls.Add(this.BTNLogin);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.textboxUser);
            this.panel1.Controls.Add(this.textBoxPass);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(400, 112);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(623, 417);
            this.panel1.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Algerian", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label3.Location = new System.Drawing.Point(110, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 21);
            this.label3.TabIndex = 21;
            this.label3.Text = "LOGIN AS ";
            // 
            // logincomboBox
            // 
            this.logincomboBox.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.logincomboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.logincomboBox.DropDownWidth = 188;
            this.logincomboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logincomboBox.FormattingEnabled = true;
            this.logincomboBox.Items.AddRange(new object[] {
            "ADMIN",
            "USER"});
            this.logincomboBox.Location = new System.Drawing.Point(301, 31);
            this.logincomboBox.Name = "logincomboBox";
            this.logincomboBox.Size = new System.Drawing.Size(206, 32);
            this.logincomboBox.TabIndex = 20;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BackgroundImage = global::STOCK__MANAGEMENT_SYSTEM.Properties.Resources.images__5_;
            this.ClientSize = new System.Drawing.Size(1350, 535);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "STOCK SOFTWARE";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxPass;
        private System.Windows.Forms.TextBox textboxUser;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnEXIT;
        private System.Windows.Forms.Button BTNLogin;
        private System.Windows.Forms.Button Btn_Clear;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox logincomboBox;
    }
}

