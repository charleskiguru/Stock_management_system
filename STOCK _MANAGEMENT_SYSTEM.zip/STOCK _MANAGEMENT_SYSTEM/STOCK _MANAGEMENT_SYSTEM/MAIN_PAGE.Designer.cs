﻿namespace STOCK__MANAGEMENT_SYSTEM
{
    partial class MAIN_PAGE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.aDDPRODUCTSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nEWPRODUCTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aDDNEWCATEGOTYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mANAGESTOCKToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mANAGESTOCKToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.mESSAGESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mANAGEORDERSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sALESREPORTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sTOCKREPORTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mANAGEUSERSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lOGOUTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lOGOUTToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.bACKUPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bACKUPDATAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rESTOREDATAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.calculatorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.workingHoursToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelusertype = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Elephant", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aDDPRODUCTSToolStripMenuItem,
            this.mANAGESTOCKToolStripMenuItem,
            this.mANAGEORDERSToolStripMenuItem,
            this.mANAGEUSERSToolStripMenuItem,
            this.lOGOUTToolStripMenuItem,
            this.lOGOUTToolStripMenuItem1,
            this.bACKUPToolStripMenuItem,
            this.toolStripMenuItem1,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem2,
            this.logoutToolStripMenuItem2});
            this.menuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1362, 29);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // aDDPRODUCTSToolStripMenuItem
            // 
            this.aDDPRODUCTSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nEWPRODUCTToolStripMenuItem,
            this.aDDNEWCATEGOTYToolStripMenuItem});
            this.aDDPRODUCTSToolStripMenuItem.Name = "aDDPRODUCTSToolStripMenuItem";
            this.aDDPRODUCTSToolStripMenuItem.Size = new System.Drawing.Size(105, 25);
            this.aDDPRODUCTSToolStripMenuItem.Text = "Products";
            this.aDDPRODUCTSToolStripMenuItem.Click += new System.EventHandler(this.aDDPRODUCTSToolStripMenuItem_Click);
            // 
            // nEWPRODUCTToolStripMenuItem
            // 
            this.nEWPRODUCTToolStripMenuItem.Name = "nEWPRODUCTToolStripMenuItem";
            this.nEWPRODUCTToolStripMenuItem.Size = new System.Drawing.Size(205, 26);
            this.nEWPRODUCTToolStripMenuItem.Text = "New product";
            this.nEWPRODUCTToolStripMenuItem.Click += new System.EventHandler(this.nEWPRODUCTToolStripMenuItem_Click);
            // 
            // aDDNEWCATEGOTYToolStripMenuItem
            // 
            this.aDDNEWCATEGOTYToolStripMenuItem.Name = "aDDNEWCATEGOTYToolStripMenuItem";
            this.aDDNEWCATEGOTYToolStripMenuItem.Size = new System.Drawing.Size(205, 26);
            this.aDDNEWCATEGOTYToolStripMenuItem.Text = "Add category";
            this.aDDNEWCATEGOTYToolStripMenuItem.Click += new System.EventHandler(this.aDDNEWCATEGOTYToolStripMenuItem_Click);
            // 
            // mANAGESTOCKToolStripMenuItem
            // 
            this.mANAGESTOCKToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mANAGESTOCKToolStripMenuItem1,
            this.mESSAGESToolStripMenuItem});
            this.mANAGESTOCKToolStripMenuItem.Name = "mANAGESTOCKToolStripMenuItem";
            this.mANAGESTOCKToolStripMenuItem.Size = new System.Drawing.Size(71, 25);
            this.mANAGESTOCKToolStripMenuItem.Text = "Stock";
            this.mANAGESTOCKToolStripMenuItem.Click += new System.EventHandler(this.mANAGESTOCKToolStripMenuItem_Click_1);
            // 
            // mANAGESTOCKToolStripMenuItem1
            // 
            this.mANAGESTOCKToolStripMenuItem1.Name = "mANAGESTOCKToolStripMenuItem1";
            this.mANAGESTOCKToolStripMenuItem1.Size = new System.Drawing.Size(207, 26);
            this.mANAGESTOCKToolStripMenuItem1.Text = "Manage stock";
            this.mANAGESTOCKToolStripMenuItem1.Click += new System.EventHandler(this.mANAGESTOCKToolStripMenuItem1_Click);
            // 
            // mESSAGESToolStripMenuItem
            // 
            this.mESSAGESToolStripMenuItem.Name = "mESSAGESToolStripMenuItem";
            this.mESSAGESToolStripMenuItem.Size = new System.Drawing.Size(207, 26);
            this.mESSAGESToolStripMenuItem.Text = " Stock out";
            this.mESSAGESToolStripMenuItem.Click += new System.EventHandler(this.mESSAGESToolStripMenuItem_Click_1);
            // 
            // mANAGEORDERSToolStripMenuItem
            // 
            this.mANAGEORDERSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sALESREPORTToolStripMenuItem,
            this.sTOCKREPORTToolStripMenuItem});
            this.mANAGEORDERSToolStripMenuItem.Name = "mANAGEORDERSToolStripMenuItem";
            this.mANAGEORDERSToolStripMenuItem.Size = new System.Drawing.Size(85, 25);
            this.mANAGEORDERSToolStripMenuItem.Text = "Report";
            this.mANAGEORDERSToolStripMenuItem.Click += new System.EventHandler(this.mANAGEORDERSToolStripMenuItem_Click_1);
            // 
            // sALESREPORTToolStripMenuItem
            // 
            this.sALESREPORTToolStripMenuItem.Name = "sALESREPORTToolStripMenuItem";
            this.sALESREPORTToolStripMenuItem.Size = new System.Drawing.Size(191, 26);
            this.sALESREPORTToolStripMenuItem.Text = "Sales report";
            this.sALESREPORTToolStripMenuItem.Click += new System.EventHandler(this.sALESREPORTToolStripMenuItem_Click);
            // 
            // sTOCKREPORTToolStripMenuItem
            // 
            this.sTOCKREPORTToolStripMenuItem.Name = "sTOCKREPORTToolStripMenuItem";
            this.sTOCKREPORTToolStripMenuItem.Size = new System.Drawing.Size(191, 26);
            this.sTOCKREPORTToolStripMenuItem.Text = "Stock report";
            this.sTOCKREPORTToolStripMenuItem.Click += new System.EventHandler(this.sTOCKREPORTToolStripMenuItem_Click_1);
            // 
            // mANAGEUSERSToolStripMenuItem
            // 
            this.mANAGEUSERSToolStripMenuItem.Name = "mANAGEUSERSToolStripMenuItem";
            this.mANAGEUSERSToolStripMenuItem.Size = new System.Drawing.Size(116, 25);
            this.mANAGEUSERSToolStripMenuItem.Text = "New users";
            this.mANAGEUSERSToolStripMenuItem.Click += new System.EventHandler(this.mANAGEUSERSToolStripMenuItem_Click_1);
            // 
            // lOGOUTToolStripMenuItem
            // 
            this.lOGOUTToolStripMenuItem.Name = "lOGOUTToolStripMenuItem";
            this.lOGOUTToolStripMenuItem.Size = new System.Drawing.Size(109, 25);
            this.lOGOUTToolStripMenuItem.Text = "Suppliers";
            this.lOGOUTToolStripMenuItem.Click += new System.EventHandler(this.lOGOUTToolStripMenuItem_Click_2);
            // 
            // lOGOUTToolStripMenuItem1
            // 
            this.lOGOUTToolStripMenuItem1.Name = "lOGOUTToolStripMenuItem1";
            this.lOGOUTToolStripMenuItem1.Size = new System.Drawing.Size(163, 25);
            this.lOGOUTToolStripMenuItem1.Text = "Manage orders";
            this.lOGOUTToolStripMenuItem1.Click += new System.EventHandler(this.lOGOUTToolStripMenuItem1_Click);
            // 
            // bACKUPToolStripMenuItem
            // 
            this.bACKUPToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bACKUPDATAToolStripMenuItem,
            this.rESTOREDATAToolStripMenuItem});
            this.bACKUPToolStripMenuItem.Name = "bACKUPToolStripMenuItem";
            this.bACKUPToolStripMenuItem.Size = new System.Drawing.Size(93, 25);
            this.bACKUPToolStripMenuItem.Text = "Backup";
            // 
            // bACKUPDATAToolStripMenuItem
            // 
            this.bACKUPDATAToolStripMenuItem.Name = "bACKUPDATAToolStripMenuItem";
            this.bACKUPDATAToolStripMenuItem.Size = new System.Drawing.Size(199, 26);
            this.bACKUPDATAToolStripMenuItem.Text = "Backup data";
            // 
            // rESTOREDATAToolStripMenuItem
            // 
            this.rESTOREDATAToolStripMenuItem.Name = "rESTOREDATAToolStripMenuItem";
            this.rESTOREDATAToolStripMenuItem.Size = new System.Drawing.Size(199, 26);
            this.rESTOREDATAToolStripMenuItem.Text = "Restore data";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(12, 25);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(103, 25);
            this.toolStripMenuItem3.Text = "About us";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Checked = true;
            this.toolStripMenuItem4.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(92, 25);
            this.toolStripMenuItem4.Text = "History";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.calculatorToolStripMenuItem,
            this.workingHoursToolStripMenuItem});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(72, 25);
            this.toolStripMenuItem2.Text = "More";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // calculatorToolStripMenuItem
            // 
            this.calculatorToolStripMenuItem.Name = "calculatorToolStripMenuItem";
            this.calculatorToolStripMenuItem.Size = new System.Drawing.Size(220, 26);
            this.calculatorToolStripMenuItem.Text = "Calculator";
            this.calculatorToolStripMenuItem.Click += new System.EventHandler(this.calculatorToolStripMenuItem_Click);
            // 
            // workingHoursToolStripMenuItem
            // 
            this.workingHoursToolStripMenuItem.Name = "workingHoursToolStripMenuItem";
            this.workingHoursToolStripMenuItem.Size = new System.Drawing.Size(220, 26);
            this.workingHoursToolStripMenuItem.Text = "Working hours";
            this.workingHoursToolStripMenuItem.Click += new System.EventHandler(this.workingHoursToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem2
            // 
            this.logoutToolStripMenuItem2.Name = "logoutToolStripMenuItem2";
            this.logoutToolStripMenuItem2.Size = new System.Drawing.Size(87, 25);
            this.logoutToolStripMenuItem2.Text = "Logout";
            this.logoutToolStripMenuItem2.Click += new System.EventHandler(this.logoutToolStripMenuItem2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Green;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Location = new System.Drawing.Point(1001, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(2, 15);
            this.label1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Green;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1124, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 27);
            this.label2.TabIndex = 3;
            this.label2.Text = "Welcome";
            // 
            // labelusertype
            // 
            this.labelusertype.AutoSize = true;
            this.labelusertype.BackColor = System.Drawing.Color.Green;
            this.labelusertype.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelusertype.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelusertype.Location = new System.Drawing.Point(1240, 2);
            this.labelusertype.Name = "labelusertype";
            this.labelusertype.Size = new System.Drawing.Size(110, 27);
            this.labelusertype.TabIndex = 4;
            this.labelusertype.Text = "Welcome";
            // 
            // MAIN_PAGE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(1362, 394);
            this.Controls.Add(this.labelusertype);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "MAIN_PAGE";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MAIN_PAGE";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MAIN_PAGE_FormClosed);
            this.Load += new System.EventHandler(this.MAIN_PAGE_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem aDDPRODUCTSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mANAGESTOCKToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mANAGEORDERSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mANAGEUSERSToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem lOGOUTToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem mANAGESTOCKToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem mESSAGESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sALESREPORTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nEWPRODUCTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aDDNEWCATEGOTYToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sTOCKREPORTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lOGOUTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bACKUPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bACKUPDATAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rESTOREDATAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem calculatorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem workingHoursToolStripMenuItem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelusertype;
    }
}