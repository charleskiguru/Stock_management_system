﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STOCK__MANAGEMENT_SYSTEM
{
    public partial class MAIN_PAGE : Form
    {
        public MAIN_PAGE(string usertype)
        {
            InitializeComponent();
            labelusertype.Text = usertype;
            if (labelusertype.Text == "USER")
            {
                mANAGEORDERSToolStripMenuItem.Visible = false;
                mANAGEUSERSToolStripMenuItem.Visible = false;
                toolStripMenuItem4.Visible = false;
                bACKUPToolStripMenuItem.Visible = false;

            }

        }

        private void lOGOUTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
             
        }

        private void aDDSTOCKToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void mANAGESTOCKToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void mANAGEORDERSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void aLERTMESSAGESToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void MAIN_PAGE_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
           
        }

        private void mANAGEUSERSToolStripMenuItem_Click(object sender, EventArgs e)
        {
           

        }

        private void lOGOUTToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void aDDPRODUCTSToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void mANAGESTOCKToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

            
        }

        private void mANAGEORDERSToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            
        }

        private void mESSAGESToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ALERT_MESSAGE obj = new ALERT_MESSAGE();
            obj.Show();
        }

       

        private void lOGOUTToolStripMenuItem_Click_2(object sender, EventArgs e)
        {
            SUPPLIERS_DETAIL obj = new SUPPLIERS_DETAIL();
            obj.Show();
        }

        private void mANAGEUSERSToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            NEW_USER obj = new NEW_USER();
            obj.Show();
         
        }

        private void lOGOUTToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            RECEIPT obj = new RECEIPT();
            obj.Show();
            //this.Hide();
        }

        private void mANAGESTOCKToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MANAGE_STOCKS obj = new MANAGE_STOCKS();
            obj.Show();
            
        }

        private void mESSAGESToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            ALERT_MESSAGE OBJ = new ALERT_MESSAGE();
            OBJ.Show();
            //this.Hide();
        }

        private void sALESREPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            REPORT obj = new REPORT();
            obj.Show();

        }

        private void nEWPRODUCTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ADD_PRODUCTS obj = new ADD_PRODUCTS();
            obj.Show();
        }

        private void aDDNEWCATEGOTYToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MANAGE_CATEGORY obj = new MANAGE_CATEGORY();
            obj.Show();
           // this.Hide();
        }

        private void sTOCKREPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
        
        }

        private void sTOCKREPORTToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            STOCK_REPORTS obj = new STOCK_REPORTS();
            obj.Show();
        }

        private void logoutToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Form1 obj = new Form1();
            obj.Show();
            this.Hide();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            CONTACTS obj = new CONTACTS();
            obj.Show();
        }

        private void MAIN_PAGE_Load(object sender, EventArgs e)
        {

        }

        private void calculatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CALCULATOR obj = new CALCULATOR();
            obj.Show();
        }

        private void workingHoursToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MORE obj = new MORE();
            obj.Show();
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            HistoryPage obj = new HistoryPage();
            obj.Show();
        }
    }
}
