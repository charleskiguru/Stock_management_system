﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace STOCK__MANAGEMENT_SYSTEM
{
    public partial class SUPPLIERS_DETAIL : Form
    {
        static string Constring = "server=localhost;database=storedb;Uid=root;Pwd=;";
        MySqlConnection connection = new MySqlConnection(Constring);
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();

        public SUPPLIERS_DETAIL()
        {
            InitializeComponent();
            retrieve();
        }
        private void retrieve()
        {
            // DateTime datetime = DateTime.Now;
            // this.label9.Text = datetime.ToString();
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM suppliers;", connection);
            try
            {
                adapter = new MySqlDataAdapter(cmd);
                adapter.SelectCommand = cmd;
                dt = new DataTable();
                adapter.Fill(dt);
                BindingSource bs = new BindingSource();

                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
                adapter.Update(dt);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }
        private void BTNSAVE_Click(object sender, EventArgs e)
        {
            if ( txtSupplierName.Text == "" || txtCompanyName.Text == "" || txtEmail.Text == "" || txtPhone.Text == "" || txtAccount.Text == "")
            {
                MessageBox.Show("Please enter all the fields!!");

            }
            else
            {

                string sql = "SELECT * FROM suppliers WHERE Supplier_Name='" + txtSupplierName.Text + "'";
                cmd = new MySqlCommand(sql, connection);
                MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(ds);
                int i = ds.Tables[0].Rows.Count;
                if (i > 0)
                {
                    MessageBox.Show("Sorry,  The supplier Name ......" + txtSupplierName.Text + "\n Already Exist");
                    ds.Clear();

                }
                else
                {
                    try
                    {

                        connection.Open();
                        string query = "INSERT INTO suppliers (Supplier_Name, Company_Name, Phone, Address, Account) VALUES ('" + txtSupplierName.Text + "' ,'" +txtCompanyName.Text + "','" + txtPhone.Text + "','" + txtEmail.Text + "','" + txtAccount.Text + "')";
                        cmd = new MySqlCommand(query, connection);
                        cmd.ExecuteNonQuery();


                        adapter = new MySqlDataAdapter("SELECT * FROM suppliers ", connection);
                        adapter.Fill(dt);
                        dataGridView1.DataSource = dt;
                        MessageBox.Show("New Suppier Saved Successfully");
                        retrieve();
                        clear();
                        connection.Close();
                    }

                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
            }
        }
        private void delete(int id)
        {
            string sql = "DELETE FROM suppliers WHERE Supplier_ID=" + id + "";
            try
            {
                connection.Open();
                cmd = new MySqlCommand(sql, connection);
                adapter = new MySqlDataAdapter(cmd);
                adapter.DeleteCommand = connection.CreateCommand();
                adapter.DeleteCommand.CommandText = sql;

                if (MessageBox.Show("Want to delete this Supplier from database??", "confirmation messsage", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                {
                    if (adapter.DeleteCommand.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("Supplier Seccesfully deleted");
                       clear();

                    }
                }
                else
                {
                    clear();
                }
                connection.Close();
                retrieve();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtSupplierName.Text == "" || txtCompanyName.Text == "" || txtEmail.Text == "" || txtPhone.Text == "" || txtAccount.Text == "")
            {
                MessageBox.Show("Select the Supplier to be deleted!!");
            }
            else
            {
                string selected = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                int id = Convert.ToInt32(selected);

                delete(id);

            }
        }

        private void clear()
        {
            txtSupplierName.Clear();
            txtCompanyName.Clear();
            txtEmail.Clear();
            txtPhone.Clear();
            txtAccount.Clear();
            txtSupplierName.Focus();

        }
        private void Update(int Supplier_ID, string Supplier_Name,string  Company_Name,string  Phone,string  Address,string  Account)
        {
            string sql = "UPDATE suppliers SET Supplier_Name='"+ Supplier_Name + "', Company_Name='"+ Company_Name + "',Phone='"+ Phone + "',Address='"+ Address + "',Account='"+ Account + "'WHERE Supplier_ID='"+ Supplier_ID + "' ";
            cmd = new MySqlCommand(sql, connection);

            try
            {
                connection.Open();
                adapter = new MySqlDataAdapter(cmd);
                adapter.UpdateCommand = connection.CreateCommand();
                adapter.UpdateCommand.CommandText = sql;

                if (MessageBox.Show("Do you want to update this Supplier??", "confirmation message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (adapter.UpdateCommand.ExecuteNonQuery()>0)
                    {
                        MessageBox.Show("Successfully Modified");
                        retrieve();
                        clear();

                    }

                }



                    connection.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }
        private void BTNUPDATE_Click(object sender, EventArgs e)
        {
            if (txtSupplierName.Text == "" || txtCompanyName.Text == "" || txtEmail.Text == "" || txtPhone.Text == "" || txtAccount.Text == "")
            {
                MessageBox.Show("Select the supplier to be Updated or Modified!!!");
            }
            else
            {
                string selected = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                int Supplier_ID = Convert.ToInt32(selected);

                Update(Supplier_ID, txtSupplierName.Text, txtCompanyName.Text, txtEmail.Text, txtPhone.Text, txtAccount.Text);
            }

            }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
          //  txtSupplierID.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            txtSupplierName.Text= dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            txtCompanyName.Text= dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            txtPhone.Text= dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            txtEmail.Text= dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            txtAccount.Text= dataGridView1.SelectedRows[0].Cells[5].Value.ToString();

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void txtPhone_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAccount_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPhone_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void txtAccount_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }
    }
}