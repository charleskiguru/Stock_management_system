﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;

namespace STOCK__MANAGEMENT_SYSTEM
{
    public partial class ADD_PRODUCTS : Form
    {
        MySqlConnection connection = new MySqlConnection("server=localhost;database=storedb;Uid=root;Pwd=;");
        MySqlCommand cmd;
    //    MySqlDataAdapter adapter;
          MySqlDataReader dr;
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
         public ADD_PRODUCTS()
        {
            InitializeComponent();

            fill_combo();
           fill_combo1();


        }
         public void Add(string proname, string catename, string stock, string price, string date, string alert, string description)
         {

    

        }
   private void buttonINSERT_Click(object sender, EventArgs e)
        {
            if (textBoxProduct.Text == "" || textBoxSTOCK.Text== ""||textBoxALERT.Text==""||comboCategory.Text==""||textBoxDESC .Text ==""|| textBoxPRICE.Text ==""||cmbSection.Text==""||cmbSupplier.Text=="")
            {
                MessageBox.Show("Please fill all the fields!!");
               
               // this.label11.Text = "Please fill all the fields!!";
            }
            else
            {
                string sql = "SELECT * FROM store WHERE proname='" + textBoxProduct.Text + "'";
                cmd = new MySqlCommand(sql, connection);
                MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(ds);
                int i = ds.Tables[0].Rows.Count;
                if (i > 0)
                {
                    MessageBox.Show("This product Name exist in the Database you can only Update","ERROR MESSAGE",MessageBoxButtons.OKCancel,MessageBoxIcon.Error);
                    ds.Clear();
                    //connection.Open();
                    //cmd.Connection = connection;
                    //cmd.CommandType = CommandType.Text;
                    //cmd.CommandText = "SELECT * FROM store WHERE proname='" + textBoxProduct.Text.Trim() + "'";
                    //dr = cmd.ExecuteReader();

                  
                    ////if (dr.HasRows)
                    //{
                    //   connection.Close();
                    //    string query = "UPDATE store SET stock=stock+'" + textBoxSTOCK.Text.Trim() + "' WHERE proname='"+textBoxProduct.Text+"' ";
                    //    cmd = new MySqlCommand(query, connection);
                    //    connection.Open();
                    //    adapter = new MySqlDataAdapter(cmd);
                    //    adapter.UpdateCommand = connection.CreateCommand();
                    //    adapter.UpdateCommand.CommandText = query;

                    //    if (MessageBox.Show("The product is already in Database \n Do you wish to update its Quantity??", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    //    {
                    //        if (adapter.UpdateCommand.ExecuteNonQuery() > 0)
                    //        {
                    //            MessageBox.Show("Product have been succesfully updated", "Success", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    //            clearText();
                    //        }
                    //    }
                    //    else
                    //    {
                    //        clearText();
                    //    }
                    //    connection.Close();
                    //}
               }
            else
                {
              try
                    {

                        connection.Open();
                        string query = "INSERT INTO  store( proname,catename,stock,price,date,alert,description,section,Supplier_Id)VALUES('" + textBoxProduct.Text + "' ,'"+comboCategory.Text+ "','" + textBoxSTOCK.Text + "','" + textBoxPRICE.Text + "','"+dateTimePicker.Text+ "','" + textBoxALERT.Text + "','" + textBoxDESC.Text+"','"+cmbSection.Text+"','"+cmbSupplier.Text +"')";
                        cmd = new MySqlCommand(query, connection);
                        cmd.ExecuteNonQuery();


                        adapter = new MySqlDataAdapter("SELECT * FROM store ", connection);
                        adapter.Fill(dt);
                     
                        MessageBox.Show("New Product Details has been Saved Successfully");
                     
                        connection.Close();
                    }

                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
            }
     }

 private void clearText()
        {
            textBoxProduct.Clear();
            comboCategory.SelectedIndex = -1;
            textBoxSTOCK.Clear();
            textBoxPRICE.Clear();
            dateTimePicker.Text = "";
            textBoxALERT.Clear();
            textBoxDESC.Clear();
           
            textBoxProduct.Focus();

        }
        private void buttonCANCEL_Click(object sender, EventArgs e)
        {
            MANAGE_STOCKS obj = new MANAGE_STOCKS();

            obj.Show();
            this.Hide();
        }

        private void textBoxALERT_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

             if (!char.IsDigit(ch) && ch != 8 && ch != 46)
             {
             e.Handled = true;
                return;
             }
        }

        private void textBoxPRICE_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void textBoxSTOCK_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            clearText();
        }

        //  byte[] imageBt = null;
        // FileStream fstream = new FileStream(this.textBoxPATH .Text ,FileMode.Open, FileAccess.Read);
        //  BinaryReader br = new BinaryReader(fstream);
        //  imageBt = br.ReadBytes((int)fstream.Length); 
        //cmd.Parameters.AddWithValue("@image",imageBt);
        private void buttonBROWSE_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "JPG Files(*.jpg)|*.jpg|PGN Files(*.png)|*.png|All Files(*.*)|*.* ";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                string picPath = dlg.FileName.ToString();
                textBoxPATH.Text = picPath;
                pictureBox1.ImageLocation = picPath;
            }
        }

        private void textBoxProduct_KeyDown(object sender, KeyEventArgs e)
        {
        }

        private void textBoxSTOCK_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void textBoxDESC_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void textBoxALERT_KeyDown(object sender, KeyEventArgs e)
        {
          
        }

        private void textBoxPRICE_KeyDown(object sender, KeyEventArgs e)
        {
           
        }

        private void textBoxPRICE_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
          
        }
        private void fill_combo()
        {
            try
            {
                connection.Open();
                string Query = "SELECT * FROM category ORDER BY category_Name ";
                cmd = new MySqlCommand(Query, connection);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    string sCategory_Name = dr.GetString("category_Name");
                    comboCategory.Items.Add(sCategory_Name);

                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }
        private void comboCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            //fill_combo();

        }
        private void fill_combo1()
        {
            try
            {
                connection.Open();
                string Query = "SELECT Supplier_Id FROM suppliers";
                cmd = new MySqlCommand(Query, connection);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    string sSupplier_Id = dr.GetString("Supplier_Id");
                    cmbSupplier.Items.Add(sSupplier_Id);

                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void ADD_PRODUCTS_Load(object sender, EventArgs e)
        {
            button1_Click(sender, e);
            //fill_combo();
        }
      
    }

  }

       
   
