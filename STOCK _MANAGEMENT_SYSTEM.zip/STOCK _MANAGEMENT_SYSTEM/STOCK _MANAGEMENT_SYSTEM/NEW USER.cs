﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace STOCK__MANAGEMENT_SYSTEM
{
    public partial class NEW_USER : Form
    {
        static string Constring = "server=localhost;database=storedb;Uid=root;Pwd=;";
        MySqlConnection connection = new MySqlConnection(Constring);
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
      
        public NEW_USER()
        {
            InitializeComponent();
        }

        private void NEW_USER_Load(object sender, EventArgs e)
        {
            retrieve();
        }
        private void retrieve()
        {
            // DateTime datetime = DateTime.Now;
            // this.label9.Text = datetime.ToString();
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM user;", connection);
            try
            {
                adapter = new MySqlDataAdapter(cmd);
                adapter.SelectCommand = cmd;
                dt = new DataTable();
                adapter.Fill(dt);
                BindingSource bs = new BindingSource();

                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
                adapter.Update(dt);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }
        private void clear()
        {
            textBoxuser.Clear();
            textBoxpass.Clear();
            textBoxuser.Focus();
        }
        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            textBoxuser.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBoxpass.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();

        }
        private void update(int id)
        {

        }
        private void buttonADD_Click(object sender, EventArgs e)
        {

            if (textBoxuser.Text == "" || textBoxuser.Text == "")
            {
                MessageBox.Show("Please Enter Username and Password!!");
            }
            else
            {
                string sql="SELECT * FROM user WHERE username='" + textBoxuser.Text + "'";
                cmd = new MySqlCommand(sql,connection);
                MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(ds);
                int i = ds.Tables[0].Rows.Count;
                if (i > 0)
                {

                     MessageBox.Show("Sorry,Username......" + textBoxuser.Text + "\n Already Exist");
                     ds.Clear();
                     clear();
                }
                else
                {
                  try
                    { 

                        connection.Open();
                        string query = "INSERT INTO  user( username,password)VALUES('" + textBoxuser.Text + "' ,'" + textBoxpass.Text + "')";
                        cmd = new MySqlCommand(query, connection);
                        cmd.ExecuteNonQuery();


                        adapter = new MySqlDataAdapter("SELECT * FROM user ", connection);
                        adapter.Fill(dt);
                        dataGridView1.DataSource = dt;
                        MessageBox.Show("New User Saved");
                        retrieve();
                        clear();
                        connection.Close();
                    }
                   
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
            }
        }
        private void delete(int id)
        {
            string sql = "DELETE FROM user WHERE ID=" + id + "";
            try
            {
                connection.Open();
                cmd = new MySqlCommand(sql, connection);
                adapter = new MySqlDataAdapter(cmd);
                adapter.DeleteCommand = connection.CreateCommand();
                adapter.DeleteCommand.CommandText = sql;

                if (MessageBox.Show("Want to delete this User from database??", "confirmation messsage", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                {
                    if (adapter.DeleteCommand.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("User Seccesfully deleted");
                        clear();

                    }
                }
                else
                {
                    clear();
                }
                connection.Close();
                retrieve();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void buttonDEL_Click(object sender, EventArgs e)
        {
            if (textBoxuser.Text == "" || textBoxpass.Text == "")
            {
                MessageBox.Show("Select row to be deleted");
            }
            else
            {
                string selected = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                int id = Convert.ToInt32(selected);

                delete(id);

            }
        }

    }
    }
