﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace STOCK__MANAGEMENT_SYSTEM
{
    public partial class ALERT_MESSAGE : Form

    {
        static string conString = "server=localhost;database=storedb;Uid=root;PWd=;";
        MySqlConnection con = new MySqlConnection(conString);
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable table = new DataTable();
        public ALERT_MESSAGE()
        {
            InitializeComponent();
            retrieve();

        }

        private void populate(string proname,string catename,string price,string description,string stock)
        {
            dataGridView1.Rows.Add(proname, catename,  price,  description,stock);
        }

        private void retrieve()
        {
            
           dataGridView1.Rows.Clear();
            string sql = "SELECT proname,catename,price,description,stock FROM store WHERE stock<alert";
            cmd = new MySqlCommand(sql, con);
       


            try
            {
                con.Open();
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(table);
                adapter.Update(table);

                foreach(DataRow row in table.Rows)
                {
                    populate (row[0].ToString(), row[1].ToString(), row[2].ToString(), row[3].ToString(), row[4].ToString());
                }
                con.Close();
                table.Rows.Clear();
            }

            catch(Exception ex)

            {
                MessageBox.Show(ex.Message);
                con.Close();
            }
        }

       
    }
}
