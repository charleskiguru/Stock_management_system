﻿namespace STOCK__MANAGEMENT_SYSTEM
{
    partial class USER_MAIN_PAGE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.mANAGEORDERSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pRINTRECEIPTSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mESSAGESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cONTACTSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mOREToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cONTACTSToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.mOREToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lOGOUTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Elephant", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.mANAGEORDERSToolStripMenuItem,
            this.mESSAGESToolStripMenuItem,
            this.cONTACTSToolStripMenuItem,
            this.mOREToolStripMenuItem,
            this.lOGOUTToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(987, 29);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(12, 25);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(12, 25);
            // 
            // mANAGEORDERSToolStripMenuItem
            // 
            this.mANAGEORDERSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pRINTRECEIPTSToolStripMenuItem});
            this.mANAGEORDERSToolStripMenuItem.Name = "mANAGEORDERSToolStripMenuItem";
            this.mANAGEORDERSToolStripMenuItem.Size = new System.Drawing.Size(220, 25);
            this.mANAGEORDERSToolStripMenuItem.Text = "MANAGE ORDERS";
            this.mANAGEORDERSToolStripMenuItem.Click += new System.EventHandler(this.mANAGEORDERSToolStripMenuItem_Click_1);
            // 
            // pRINTRECEIPTSToolStripMenuItem
            // 
            this.pRINTRECEIPTSToolStripMenuItem.Name = "pRINTRECEIPTSToolStripMenuItem";
            this.pRINTRECEIPTSToolStripMenuItem.Size = new System.Drawing.Size(266, 26);
            this.pRINTRECEIPTSToolStripMenuItem.Text = "PRINT RECEIPTS";
            this.pRINTRECEIPTSToolStripMenuItem.Click += new System.EventHandler(this.pRINTRECEIPTSToolStripMenuItem_Click);
            // 
            // mESSAGESToolStripMenuItem
            // 
            this.mESSAGESToolStripMenuItem.Name = "mESSAGESToolStripMenuItem";
            this.mESSAGESToolStripMenuItem.Size = new System.Drawing.Size(141, 25);
            this.mESSAGESToolStripMenuItem.Text = "MESSAGES";
            this.mESSAGESToolStripMenuItem.Click += new System.EventHandler(this.mESSAGESToolStripMenuItem_Click_1);
            // 
            // cONTACTSToolStripMenuItem
            // 
            this.cONTACTSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mOREToolStripMenuItem1,
            this.cONTACTSToolStripMenuItem1});
            this.cONTACTSToolStripMenuItem.Name = "cONTACTSToolStripMenuItem";
            this.cONTACTSToolStripMenuItem.Size = new System.Drawing.Size(131, 25);
            this.cONTACTSToolStripMenuItem.Text = "ABOUT US";
            this.cONTACTSToolStripMenuItem.Click += new System.EventHandler(this.cONTACTSToolStripMenuItem_Click_1);
            // 
            // mOREToolStripMenuItem1
            // 
            this.mOREToolStripMenuItem1.Name = "mOREToolStripMenuItem1";
            this.mOREToolStripMenuItem1.Size = new System.Drawing.Size(201, 26);
            this.mOREToolStripMenuItem1.Text = "MORE";
            this.mOREToolStripMenuItem1.Click += new System.EventHandler(this.mOREToolStripMenuItem1_Click);
            // 
            // cONTACTSToolStripMenuItem1
            // 
            this.cONTACTSToolStripMenuItem1.Name = "cONTACTSToolStripMenuItem1";
            this.cONTACTSToolStripMenuItem1.Size = new System.Drawing.Size(201, 26);
            this.cONTACTSToolStripMenuItem1.Text = "CONTACTS ";
            this.cONTACTSToolStripMenuItem1.Click += new System.EventHandler(this.cONTACTSToolStripMenuItem1_Click);
            // 
            // mOREToolStripMenuItem
            // 
            this.mOREToolStripMenuItem.Name = "mOREToolStripMenuItem";
            this.mOREToolStripMenuItem.Size = new System.Drawing.Size(172, 25);
            this.mOREToolStripMenuItem.Text = "CALCULATOR";
            this.mOREToolStripMenuItem.Click += new System.EventHandler(this.mOREToolStripMenuItem_Click_1);
            // 
            // lOGOUTToolStripMenuItem
            // 
            this.lOGOUTToolStripMenuItem.Name = "lOGOUTToolStripMenuItem";
            this.lOGOUTToolStripMenuItem.Size = new System.Drawing.Size(111, 25);
            this.lOGOUTToolStripMenuItem.Text = "LOGOUT";
            this.lOGOUTToolStripMenuItem.Click += new System.EventHandler(this.lOGOUTToolStripMenuItem_Click_1);
            // 
            // USER_MAIN_PAGE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(987, 533);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "USER_MAIN_PAGE";
            this.Text = "USER_MAIN_PAGE";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem mANAGEORDERSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mESSAGESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cONTACTSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lOGOUTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mOREToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cONTACTSToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem mOREToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pRINTRECEIPTSToolStripMenuItem;
    }
}