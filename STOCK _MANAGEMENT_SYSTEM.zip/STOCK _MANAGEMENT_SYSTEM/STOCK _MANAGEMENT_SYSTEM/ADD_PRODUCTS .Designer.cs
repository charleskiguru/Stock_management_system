﻿using System;

namespace STOCK__MANAGEMENT_SYSTEM
{
    partial class ADD_PRODUCTS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtSupplierName = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.cmbSupplier = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.cmbSection = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxPATH = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.buttonBROWSE = new System.Windows.Forms.Button();
            this.buttonINSERT = new System.Windows.Forms.Button();
            this.buttonCANCEL = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.comboCategory = new System.Windows.Forms.ComboBox();
            this.textBoxDESC = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxALERT = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxPRICE = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxSTOCK = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxProduct = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.txtSupplierName);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.cmbSupplier);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.cmbSection);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.textBoxPATH);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.buttonBROWSE);
            this.panel1.Controls.Add(this.buttonINSERT);
            this.panel1.Controls.Add(this.buttonCANCEL);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.dateTimePicker);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.comboCategory);
            this.panel1.Controls.Add(this.textBoxDESC);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.textBoxALERT);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.textBoxPRICE);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.textBoxSTOCK);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.textBoxProduct);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(2, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(767, 557);
            this.panel1.TabIndex = 0;
            // 
            // txtSupplierName
            // 
            this.txtSupplierName.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSupplierName.Location = new System.Drawing.Point(591, 337);
            this.txtSupplierName.MaxLength = 10;
            this.txtSupplierName.Name = "txtSupplierName";
            this.txtSupplierName.Size = new System.Drawing.Size(153, 23);
            this.txtSupplierName.TabIndex = 71;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(477, 344);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(108, 16);
            this.label14.TabIndex = 70;
            this.label14.Text = "SUPPLIER NAME";
            // 
            // cmbSupplier
            // 
            this.cmbSupplier.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSupplier.FormattingEnabled = true;
            this.cmbSupplier.Location = new System.Drawing.Point(589, 294);
            this.cmbSupplier.Name = "cmbSupplier";
            this.cmbSupplier.Size = new System.Drawing.Size(148, 21);
            this.cmbSupplier.TabIndex = 69;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(497, 299);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(86, 16);
            this.label13.TabIndex = 68;
            this.label13.Text = "SUPPLIER ID";
            // 
            // cmbSection
            // 
            this.cmbSection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSection.FormattingEnabled = true;
            this.cmbSection.Items.AddRange(new object[] {
            "A",
            "B",
            "C",
            "D",
            "E",
            "F"});
            this.cmbSection.Location = new System.Drawing.Point(589, 246);
            this.cmbSection.Name = "cmbSection";
            this.cmbSection.Size = new System.Drawing.Size(148, 21);
            this.cmbSection.TabIndex = 67;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(510, 251);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 16);
            this.label12.TabIndex = 66;
            this.label12.Text = "SECTION";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(268, 311);
            this.textBox1.MaxLength = 10;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(200, 23);
            this.textBox1.TabIndex = 64;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(128, 314);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(95, 16);
            this.label10.TabIndex = 63;
            this.label10.Text = "BUYING PRICE";
            // 
            // textBoxPATH
            // 
            this.textBoxPATH.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPATH.Location = new System.Drawing.Point(537, 165);
            this.textBoxPATH.Name = "textBoxPATH";
            this.textBoxPATH.Size = new System.Drawing.Size(200, 23);
            this.textBoxPATH.TabIndex = 60;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(586, 12);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 16);
            this.label9.TabIndex = 59;
            this.label9.Text = "Image\r\n";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(210, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 13);
            this.label8.TabIndex = 58;
            // 
            // buttonBROWSE
            // 
            this.buttonBROWSE.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBROWSE.Location = new System.Drawing.Point(589, 194);
            this.buttonBROWSE.Name = "buttonBROWSE";
            this.buttonBROWSE.Size = new System.Drawing.Size(75, 27);
            this.buttonBROWSE.TabIndex = 57;
            this.buttonBROWSE.Text = "BROWSE";
            this.buttonBROWSE.UseVisualStyleBackColor = true;
            this.buttonBROWSE.Click += new System.EventHandler(this.buttonBROWSE_Click);
            // 
            // buttonINSERT
            // 
            this.buttonINSERT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonINSERT.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonINSERT.ForeColor = System.Drawing.Color.Red;
            this.buttonINSERT.Location = new System.Drawing.Point(268, 456);
            this.buttonINSERT.Name = "buttonINSERT";
            this.buttonINSERT.Size = new System.Drawing.Size(109, 48);
            this.buttonINSERT.TabIndex = 56;
            this.buttonINSERT.Text = "SAVE";
            this.buttonINSERT.UseVisualStyleBackColor = true;
            this.buttonINSERT.Click += new System.EventHandler(this.buttonINSERT_Click);
            // 
            // buttonCANCEL
            // 
            this.buttonCANCEL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCANCEL.ForeColor = System.Drawing.Color.DarkRed;
            this.buttonCANCEL.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonCANCEL.Location = new System.Drawing.Point(433, 465);
            this.buttonCANCEL.Name = "buttonCANCEL";
            this.buttonCANCEL.Size = new System.Drawing.Size(59, 34);
            this.buttonCANCEL.TabIndex = 54;
            this.buttonCANCEL.Text = "NEXT";
            this.buttonCANCEL.UseVisualStyleBackColor = true;
            this.buttonCANCEL.Click += new System.EventHandler(this.buttonCANCEL_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(537, 31);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(200, 112);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 52;
            this.pictureBox1.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(128, 200);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 16);
            this.label7.TabIndex = 51;
            this.label7.Text = "DATE";
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Enabled = false;
            this.dateTimePicker.Location = new System.Drawing.Point(268, 203);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker.TabIndex = 50;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(128, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(115, 16);
            this.label6.TabIndex = 49;
            this.label6.Text = "CATEGORY NAME";
            // 
            // comboCategory
            // 
            this.comboCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboCategory.FormattingEnabled = true;
            this.comboCategory.Location = new System.Drawing.Point(271, 66);
            this.comboCategory.Name = "comboCategory";
            this.comboCategory.Size = new System.Drawing.Size(200, 21);
            this.comboCategory.TabIndex = 48;
            this.comboCategory.SelectedIndexChanged += new System.EventHandler(this.comboCategory_SelectedIndexChanged);
            // 
            // textBoxDESC
            // 
            this.textBoxDESC.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDESC.Location = new System.Drawing.Point(271, 140);
            this.textBoxDESC.Multiline = true;
            this.textBoxDESC.Name = "textBoxDESC";
            this.textBoxDESC.Size = new System.Drawing.Size(200, 48);
            this.textBoxDESC.TabIndex = 47;
            this.textBoxDESC.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxDESC_KeyDown);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(128, 155);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 16);
            this.label5.TabIndex = 46;
            this.label5.Text = "DESCRIPTION";
            // 
            // textBoxALERT
            // 
            this.textBoxALERT.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxALERT.Location = new System.Drawing.Point(268, 261);
            this.textBoxALERT.MaxLength = 10;
            this.textBoxALERT.Name = "textBoxALERT";
            this.textBoxALERT.Size = new System.Drawing.Size(200, 23);
            this.textBoxALERT.TabIndex = 45;
            this.textBoxALERT.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxALERT_KeyDown);
            this.textBoxALERT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxALERT_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(128, 261);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 16);
            this.label4.TabIndex = 44;
            this.label4.Text = "STOCK LEVEL";
            // 
            // textBoxPRICE
            // 
            this.textBoxPRICE.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPRICE.Location = new System.Drawing.Point(271, 363);
            this.textBoxPRICE.MaxLength = 10;
            this.textBoxPRICE.Name = "textBoxPRICE";
            this.textBoxPRICE.Size = new System.Drawing.Size(200, 23);
            this.textBoxPRICE.TabIndex = 43;
            this.textBoxPRICE.TextChanged += new System.EventHandler(this.textBoxPRICE_TextChanged);
            this.textBoxPRICE.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxPRICE_KeyDown);
            this.textBoxPRICE.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPRICE_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(128, 366);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 16);
            this.label3.TabIndex = 42;
            this.label3.Text = "SELLING PRICE";
            // 
            // textBoxSTOCK
            // 
            this.textBoxSTOCK.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSTOCK.Location = new System.Drawing.Point(271, 98);
            this.textBoxSTOCK.MaxLength = 10;
            this.textBoxSTOCK.Name = "textBoxSTOCK";
            this.textBoxSTOCK.Size = new System.Drawing.Size(200, 23);
            this.textBoxSTOCK.TabIndex = 41;
            this.textBoxSTOCK.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxSTOCK_KeyDown);
            this.textBoxSTOCK.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxSTOCK_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(128, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 16);
            this.label2.TabIndex = 40;
            this.label2.Text = "STOCK QUANTITY";
            // 
            // textBoxProduct
            // 
            this.textBoxProduct.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxProduct.Location = new System.Drawing.Point(271, 31);
            this.textBoxProduct.Name = "textBoxProduct";
            this.textBoxProduct.Size = new System.Drawing.Size(200, 23);
            this.textBoxProduct.TabIndex = 39;
            this.textBoxProduct.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxProduct_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(128, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 16);
            this.label1.TabIndex = 38;
            this.label1.Text = "PRODUCT NAME";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::STOCK__MANAGEMENT_SYSTEM.Properties.Resources.stock_vector_shopping_mall_icons_241007449;
            this.pictureBox2.Location = new System.Drawing.Point(775, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(393, 557);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 61;
            this.pictureBox2.TabStop = false;
            // 
            // ADD_PRODUCTS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(1180, 574);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "ADD_PRODUCTS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ADD_PRODUCTS";
            this.Load += new System.EventHandler(this.ADD_PRODUCTS_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonBROWSE;
        private System.Windows.Forms.Button buttonINSERT;
        private System.Windows.Forms.Button buttonCANCEL;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboCategory;
        private System.Windows.Forms.TextBox textBoxDESC;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxALERT;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxPRICE;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxSTOCK;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxProduct;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxPATH;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmbSection;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cmbSupplier;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtSupplierName;
        private System.Windows.Forms.Label label14;

        public EventHandler textBoxSTOCK_TextChanged { get; private set; }
    }
}