﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace STOCK__MANAGEMENT_SYSTEM
{
    public partial class ADD_CATAGORY : Form
    {
        static string conString = "server=localhost;database=storedb;Uid=root;Pwd=;";
        MySqlConnection con = new MySqlConnection(conString);
        MySqlCommand cmd;
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
   public ADD_CATAGORY()
        {
            InitializeComponent();
        }
  private void ClearTxt()
        {
            txtboxcategory.Clear();
            txtboxcategory.Focus();
        }
        private void BtnCategory_Click(object sender, EventArgs e)
        {
            if (txtboxcategory.Text=="")
            {
                MessageBox.Show("This Cannot be Empty!!");
            }
            else
            {
                string sql = "SELECT * FROM category WHERE category_Name='"+txtboxcategory.Text+"'";
                cmd = new MySqlCommand(sql, con);
                MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(ds);

                int i = ds.Tables[0].Rows.Count;
                if (i > 0)
                {
                    MessageBox.Show("The Category Name already Exits!!", "Alert Message", MessageBoxButtons.OKCancel, MessageBoxIcon.Stop);
                        ds.Clear();
                }
                else
                {

                    try
                    {
                        con.Open();
                        string query = "INSERT INTO category (category_Name)VALUES('"+txtboxcategory.Text+"') ";
                        cmd = new MySqlCommand(query, con);
                        cmd.ExecuteNonQuery();

                        //adapter = new MySqlDataAdapter("SELECT * FROM category", con);
                        //adapter.Fill(dt);
                        MessageBox.Show("Category Added Succesfully");
                        ClearTxt();

                        con.Close();



                    }
                    catch(Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }
    }
}
