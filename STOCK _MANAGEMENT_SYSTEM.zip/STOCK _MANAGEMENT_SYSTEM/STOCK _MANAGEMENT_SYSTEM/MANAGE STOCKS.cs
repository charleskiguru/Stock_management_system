﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;

namespace STOCK__MANAGEMENT_SYSTEM
{
    public partial class MANAGE_STOCKS : Form
    {
        static string conString = "server=localhost;database=storedb;Uid=root;Pwd=;";
        MySqlConnection connection = new MySqlConnection(conString);
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable dt= new DataTable();
        MySqlDataReader dr;
        
        public MANAGE_STOCKS()
        {
            InitializeComponent();
            fill_combo();

            fill_combo1();

     }


        private void MANAGE_STOCKS_Load(object sender, EventArgs e)
        {
            retrieve();
           
        }

        private void retrieve()
        {
            DateTime datetime = DateTime.Now;
            this.label9.Text = datetime.ToString();
           MySqlCommand cmd = new MySqlCommand("SELECT * FROM store;",connection);
            try
            {
                adapter = new MySqlDataAdapter(cmd);
                adapter.SelectCommand = cmd;
                dt = new DataTable();
                adapter.Fill(dt);
                BindingSource bs = new BindingSource();

                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
                adapter.Update(dt);
              }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
           
            }

        }

      private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
       {
       }

        private void update(int id, string proname, string catename, string stock, string price, string date, string alert, string description,string section,string Supplier_Id)
        {
            string sql = "UPDATE store SET proname='"+proname+" ',catename= '"+catename+"',stock='"+stock+"',price='"+price+"', date='"+date+"',alert='"+alert+"',description='"+description+ "',section='"+ section+ "',Supplier_Id='"+ Supplier_Id + "' WHERE ID=" + id+"";
            cmd = new MySqlCommand(sql,connection);

            try
            {
                connection.Open();
                adapter = new MySqlDataAdapter(cmd);
                adapter.UpdateCommand = connection.CreateCommand();
                adapter.UpdateCommand.CommandText = sql;

                if(MessageBox.Show("Do you want to update this product??","confirmation message",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
                {
                    if(adapter.UpdateCommand.ExecuteNonQuery()>0)
                    {
                        MessageBox.Show("Succesfully Updated");
                        clearText();
                        
                    }
                }

                else
                {
                    clearText();
                }
                connection.Close();
                retrieve();


            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                connection.Close();
            }
        }

        private void buttonUPADATE_Click(object sender, EventArgs e)
        {
            if(textBoxProduct.Text==""||comboCategory.Text==""||QuantitytextBox.Text==""||textBoxPRICE.Text==""||textBoxALERT.Text==""||dateTimePicker.Text==""||textBoxDESC.Text==""||cmbSection.Text==""||cmbSupplier.Text==""||cmbSupplier.Text=="")
            {
                MessageBox.Show("The row to updated should be selected ","Alert",MessageBoxButtons.OK,MessageBoxIcon.Error);



            }
            else
            {
                string selected = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                int id = Convert.ToInt32(selected);

                update( id,textBoxProduct.Text, comboCategory.Text, QuantitytextBox.Text, textBoxPRICE.Text, dateTimePicker.Text, textBoxALERT.Text, textBoxDESC.Text,cmbSection.Text,cmbSupplier.Text);
            }
        }

        private void delete(int id)
        {
            string sql = "DELETE FROM store WHERE ID="+id+"";
            try
            {
                connection.Open();
                cmd = new MySqlCommand(sql, connection);
                adapter = new MySqlDataAdapter(cmd);
                adapter.DeleteCommand = connection.CreateCommand();
                adapter.DeleteCommand.CommandText = sql;

                if(MessageBox.Show("Want to delete this product from database??","confirmation messsage",MessageBoxButtons.OKCancel,MessageBoxIcon.Question)==DialogResult.OK)
                {
                    if(adapter.DeleteCommand.ExecuteNonQuery()>0)
                    {
                        MessageBox.Show("seccesfully deleted");
                        clearText();

                    }
                }
                else
                {
                    clearText();
                }
                connection.Close();
                retrieve();

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                connection.Close();

            }
        }

        private void clearText()
        {
            textBoxProduct.Clear();
            comboCategory.SelectedIndex = -1;
            QuantitytextBox.Clear();
            textBoxPRICE.Clear();
            dateTimePicker.Text="";
            textBoxALERT.Clear();
            textBoxDESC.Clear();
            textBoxProduct.Focus();
            cmbSection.SelectedIndex = -1;
            cmbSupplier.SelectedIndex = -1;
        }

        private void buttonDELETE_Click(object sender, EventArgs e)
        {
            if(textBoxProduct.Text==""||comboCategory.Text==""||QuantitytextBox.Text==""||textBoxPRICE.Text==""||dateTimePicker.Text==""||textBoxALERT.Text==""||textBoxDESC.Text==""||cmbSection.Text==""||cmbSupplier.Text=="")
            {
                MessageBox.Show("Select a row to be DELETED", "Alert",  MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
            {
                string selected = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                int id = Convert.ToInt32(selected);
                delete(id);
            }
        }

        private void buttonEXIT_Click(object sender, EventArgs e)
        {
           
            this.Close();
            
        }

        private void QuantitytextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void textBoxPRICE_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void textBoxALERT_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            DataView DV = new DataView(dt);
            DV.RowFilter = string.Format("proname LIKE'%{0}'",textBox1.Text," catename LIKE'%{0}'",comboCategory.Text);
            dataGridView1.DataSource = DV;
        }

        private void dataGridView1_MouseClick_1(object sender, MouseEventArgs e)
        {
            textBoxProduct.Text = dataGridView1.SelectedRows[0]. Cells[1].Value.ToString();
            comboCategory.Text = dataGridView1.SelectedRows[0].  Cells[2].Value.ToString();
            QuantitytextBox.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            textBoxPRICE.Text = dataGridView1.SelectedRows[0].   Cells[4].Value.ToString();
            dateTimePicker.Text = dataGridView1.SelectedRows[0]. Cells[5].Value.ToString();
            textBoxALERT.Text = dataGridView1.SelectedRows[0].   Cells[6].Value.ToString();
            textBoxDESC.Text = dataGridView1.SelectedRows[0].    Cells[7].Value.ToString();
            cmbSection.Text= dataGridView1.SelectedRows[0].      Cells[8].Value.ToString();
            cmbSupplier.Text = dataGridView1.SelectedRows[0].Cells[9].Value.ToString();
        }

        private void buttonBACK_Click(object sender, EventArgs e)
        {
            ADD_PRODUCTS obj = new ADD_PRODUCTS();
            obj.Show();
            this.Hide();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboCategory_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void fill_combo()
        {
            try
            {
                connection.Open();
                string Query = "SELECT * FROM category ORDER BY category_Name ";
                cmd = new MySqlCommand(Query, connection);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    string sCategory_Name = dr.GetString("category_Name");
                    comboCategory.Items.Add(sCategory_Name);

                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }
        private void fill_combo1()
        {
            try
            {
                connection.Open();
                string Query = "SELECT Supplier_Id FROM suppliers";
                cmd = new MySqlCommand(Query, connection);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    string sSupplier_Id = dr.GetString("Supplier_Id");
                    cmbSupplier.Items.Add(sSupplier_Id);

                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void QuantitytextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
