﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;

using MySql.Data.MySqlClient;




namespace STOCK__MANAGEMENT_SYSTEM
{
    public partial class REPORT : Form
    {
        static string conString = "server=localhost;database=storedb;Uid=root;Pwd=;";
        MySqlConnection con = new MySqlConnection(conString);
        //   MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable dt = new DataTable();
        MySqlDataAdapter da;
        public REPORT()
        {
            InitializeComponent();

        }
       private void load()
        {
            con.Open();
            da = new MySqlDataAdapter("SELECT  * FROM report", con);
            con.Close();
            MySqlCommandBuilder cmb = new MySqlCommandBuilder(da);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

        }
        private void retrieve()
        {
           DateTime datetime = DateTime.Now;
            this.label5.Text = datetime.ToString();

            dataGridView1.Columns[0].Visible = false;
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM report", con);
            try
            {
                adapter = new MySqlDataAdapter(cmd);
                adapter.SelectCommand = cmd;
                dt = new DataTable();
                adapter.Fill(dt);

                BindingSource bs = new BindingSource();
                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
                adapter.Update(dt);


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void REPORT_Load(object sender, EventArgs e)
        {
            //  retrieve();
            load();
            button1_Click(sender, e);

        }

        private void textBoxSEARCH_TextChanged(object sender, EventArgs e)
        {
        }
      
        private void buttonPRINT_Click(object sender, EventArgs e)
           {

            printDocument1.Print();
            

            }

        private void buttonPREv_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.ShowDialog();
        }
     
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap bmp = new Bitmap(this.dataGridView1.Width, this.dataGridView1.Height);
            dataGridView1.DrawToBitmap(bmp, new System.Drawing.Rectangle(0, 0, this.dataGridView1.Width, this.dataGridView1.Height));
            e.Graphics.DrawImage(bmp, 0, 0);

            e.Graphics.DrawString("TOTAL SALES AMOUNT:   Ksh." + textBox1.Text.Trim(), new System.Drawing.Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(550,550));


       }

        private void button1_Click(object sender, EventArgs e)
        {

            //int sum = 0;
            //for (int i = 0; i < dataGridView1.Rows.Count; ++i)
            //{
            //    sum+= Convert.ToInt32(dataGridView1.Rows[i].Cells[5].Value);
            //}
            //textBox1.Text = (sum.ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            da = new MySqlDataAdapter("select * from report WHERE Date_of_Sale between '"+ dateTimePicker4.Text.ToString()+ "' AND '"+ dateTimePicker3 .Text.ToString() + "'",con);
            DataSet ds = new DataSet();
            da.Fill(ds,"report");

           // dataGridView1.Columns[0].Visible = false;
            dataGridView1.DataSource = ds.Tables["report"];
       
            con.Close();
            button1_Click(sender, e);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // retrieve();
            dataGridView1.Columns[0].Visible = false;
            load();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            int sum = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(dataGridView1.Rows[i].Cells[5].Value);
            }
            textBox1.Text = (sum.ToString());
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

            DataView DV = new DataView(dt);

            DV.RowFilter = string.Format("Product_Name LIKE '%{0}'", textBox2.Text);

            dataGridView1.DataSource = DV;
        }
    }
   }


