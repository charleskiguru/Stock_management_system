﻿namespace STOCK__MANAGEMENT_SYSTEM
{
    internal class phrase
    {
        private string v;

        public phrase(string v)
        {
            this.v = v;
        }
    }
}