﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace STOCK__MANAGEMENT_SYSTEM
{
    public partial class MANAGE_CATEGORY : Form
    {

        static string conString = "server=localhost;database=storedb;Uid=root;Pwd=;";
        MySqlConnection connection = new MySqlConnection(conString);
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable dt = new DataTable();
        //MySqlDataReader dr;
        public MANAGE_CATEGORY()
        {
            InitializeComponent();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            ADD_CATAGORY obj = new ADD_CATAGORY();
            obj.Show();
        }

        private void MANAGE_CATEGORY_Load(object sender, EventArgs e)
        {
            retrieve();
        }    
        private void retrieve()
        {
           // DateTime datetime = DateTime.Now;
           // this.label9.Text = datetime.ToString();
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM category ;", connection);
            try
            {
                adapter = new MySqlDataAdapter(cmd);
                adapter.SelectCommand = cmd;
                dt = new DataTable();
                adapter.Fill(dt);
                BindingSource bs = new BindingSource();

                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
                adapter.Update(dt);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            retrieve();
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            textBoxID.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            txtName.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();


        }
       private void update(int CateID, string category_Name)
        {

            string sql = "UPDATE category SET category_Name='" + category_Name + " 'WHERE CateID=" + CateID + "";
            cmd = new MySqlCommand(sql, connection);

            try
            {
                connection.Open();
                adapter = new MySqlDataAdapter(cmd);
                adapter.UpdateCommand = connection.CreateCommand();
                adapter.UpdateCommand.CommandText = sql;

                if (MessageBox.Show("Do you want to update this product??", "confirmation message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (adapter.UpdateCommand.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("Succesfully Updated");

                        retrieve();
                    }
                }

                else
                {
                    
                }
                connection.Close();
                retrieve();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                connection.Close();
            }

        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtName.Text=="")
            {
                MessageBox.Show("Select the category to be Updated","Alert", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {

                string selected = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                int CateID = Convert.ToInt32(selected);

                update(CateID, txtName.Text);

            }
        }
        private void delete(int CateID)
        {
            string sql = "DELETE FROM category WHERE CateID=" + CateID + "";
            try
            {
                connection.Open();
                cmd = new MySqlCommand(sql, connection);
                adapter = new MySqlDataAdapter(cmd);
                adapter.DeleteCommand = connection.CreateCommand();
                adapter.DeleteCommand.CommandText = sql;

                if (MessageBox.Show("Want to delete this product from database??", "confirmation messsage", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                {
                    if (adapter.DeleteCommand.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("seccesfully deleted");
                   

                    }
                }
                else
                {
                    
                }
                connection.Close();
                retrieve();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                connection.Close();

            }
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtName.Text=="")
            {
                MessageBox.Show("Select a row to be DELETED", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
            {
                string selected = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                int id = Convert.ToInt32(selected);
                delete(id);
            }
        }
    }
    }

