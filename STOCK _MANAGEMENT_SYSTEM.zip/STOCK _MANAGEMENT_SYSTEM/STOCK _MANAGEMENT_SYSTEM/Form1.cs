﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace STOCK__MANAGEMENT_SYSTEM
{
    public partial class Form1 : Form
    {
        static string conString = "server=localhost;database=storedb;Uid=root;Pwd=;";
        MySqlConnection con = new MySqlConnection(conString);
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        MySqlDataReader dr;

       public Form1()
        {
            InitializeComponent();
        }
        private void history()
        {
            con.Close();
            con.Open();
            string sql = "INSERT INTO history(activity,time,date)VALUES('" + textboxUser.Text.Trim() + "" + "logged in" + " ','" + DateTime.Now.ToShortTimeString() + "','" + DateTime.Now.ToShortDateString() + "')";
            cmd = new MySqlCommand(sql, con);
            adapter = new MySqlDataAdapter(cmd);
            if (cmd.ExecuteNonQuery() > 0)
            {

            }
            con.Close();
        }
        private void BTNLogin_Click(object sender, EventArgs e)
        {
           string sql = "SELECT usertype,username,password FROM user WHERE usertype='"+ logincomboBox.Text+ "' AND  username='"+this.textboxUser.Text+"' AND password='"+this.textBoxPass.Text+"'";
            cmd = new MySqlCommand(sql, con);
             try
            {
                con.Open();

                adapter = new MySqlDataAdapter(cmd);
                dr = cmd.ExecuteReader();
                int count = 0;

                while(dr.Read())
                {
                    count = count + 1;

                }
                if (count > 0)
                {
                    string usertype = logincomboBox.Text;
                    if(logincomboBox.Text=="ADMIN" )
                    {
                        history();
                        MAIN_PAGE obj = new MAIN_PAGE(usertype);
                        obj.Show();
                        this.Hide();
                    }
                    else
                    {
                        history();
                        MAIN_PAGE obj = new MAIN_PAGE(usertype);
                        obj.Show();
                        this.Hide();

                    }
                }
                else
                {
                    MessageBox.Show("Wrong Username or Password!!"); 

                }
                con.Close();

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                con.Close();
            }

        }

        private void BtnEXIT_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Btn_Clear_Click(object sender, EventArgs e)
        {
            clearText();

        }
        private void clearText()
        {
            textboxUser.Clear();
            textBoxPass.Clear();
            textboxUser.Focus();
        }

        private void textboxUser_KeyDown(object sender, KeyEventArgs e)
        {
           
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
