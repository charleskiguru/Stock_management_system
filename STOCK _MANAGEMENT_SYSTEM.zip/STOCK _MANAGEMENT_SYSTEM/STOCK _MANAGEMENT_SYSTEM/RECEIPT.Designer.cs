﻿using System;
using System.Windows.Forms;

namespace STOCK__MANAGEMENT_SYSTEM
{
    partial class RECEIPT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RECEIPT));
            this.ItemgroupBox = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textBoxQtySale = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.AddTocartbutton = new System.Windows.Forms.Button();
            this.ItemnamecomboBox = new System.Windows.Forms.ComboBox();
            this.clientnametextBox = new System.Windows.Forms.TextBox();
            this.UnitpricetextBox = new System.Windows.Forms.TextBox();
            this.QuantitytextBox = new System.Windows.Forms.TextBox();
            this.UnitPriceLabel = new System.Windows.Forms.Label();
            this.Quantitylabel = new System.Windows.Forms.Label();
            this.ItemNamelabel = new System.Windows.Forms.Label();
            this.clientnamelabel = new System.Windows.Forms.Label();
            this.NewOrderbutton = new System.Windows.Forms.Button();
            this.PrintOrderbutton = new System.Windows.Forms.Button();
            this.PrintPreviewbutton = new System.Windows.Forms.Button();
            this.CancelOrderbutton = new System.Windows.Forms.Button();
            this.CartdataGridView = new System.Windows.Forms.DataGridView();
            this.TotalAmountlabel = new System.Windows.Forms.Label();
            this.Salestaxlabel = new System.Windows.Forms.Label();
            this.TotalToPaylabel = new System.Windows.Forms.Label();
            this.TotalAmounttextBox = new System.Windows.Forms.TextBox();
            this.SalesTaxtextBox = new System.Windows.Forms.TextBox();
            this.TotalToPaytextBox = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.buttonCALC = new System.Windows.Forms.Button();
            this.ItemgroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CartdataGridView)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ItemgroupBox
            // 
            this.ItemgroupBox.Controls.Add(this.label1);
            this.ItemgroupBox.Controls.Add(this.dateTimePicker1);
            this.ItemgroupBox.Controls.Add(this.textBoxQtySale);
            this.ItemgroupBox.Controls.Add(this.label2);
            this.ItemgroupBox.Controls.Add(this.AddTocartbutton);
            this.ItemgroupBox.Controls.Add(this.ItemnamecomboBox);
            this.ItemgroupBox.Controls.Add(this.clientnametextBox);
            this.ItemgroupBox.Controls.Add(this.UnitpricetextBox);
            this.ItemgroupBox.Controls.Add(this.QuantitytextBox);
            this.ItemgroupBox.Controls.Add(this.UnitPriceLabel);
            this.ItemgroupBox.Controls.Add(this.Quantitylabel);
            this.ItemgroupBox.Controls.Add(this.ItemNamelabel);
            this.ItemgroupBox.Controls.Add(this.clientnamelabel);
            this.ItemgroupBox.Enabled = false;
            this.ItemgroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemgroupBox.Location = new System.Drawing.Point(12, 2);
            this.ItemgroupBox.Name = "ItemgroupBox";
            this.ItemgroupBox.Size = new System.Drawing.Size(981, 231);
            this.ItemgroupBox.TabIndex = 0;
            this.ItemgroupBox.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(380, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 20);
            this.label1.TabIndex = 16;
            this.label1.Text = "Date\r\n";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(470, 23);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(331, 26);
            this.dateTimePicker1.TabIndex = 15;
            // 
            // textBoxQtySale
            // 
            this.textBoxQtySale.Location = new System.Drawing.Point(307, 126);
            this.textBoxQtySale.Name = "textBoxQtySale";
            this.textBoxQtySale.ReadOnly = true;
            this.textBoxQtySale.Size = new System.Drawing.Size(115, 26);
            this.textBoxQtySale.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(270, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(216, 20);
            this.label2.TabIndex = 13;
            this.label2.Text = "Quantity available for sale";
            // 
            // AddTocartbutton
            // 
            this.AddTocartbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.AddTocartbutton.Location = new System.Drawing.Point(883, 56);
            this.AddTocartbutton.Name = "AddTocartbutton";
            this.AddTocartbutton.Size = new System.Drawing.Size(75, 123);
            this.AddTocartbutton.TabIndex = 4;
            this.AddTocartbutton.Text = "AddToCart";
            this.AddTocartbutton.UseVisualStyleBackColor = true;
            this.AddTocartbutton.Click += new System.EventHandler(this.AddTocartbutton_Click);
            // 
            // ItemnamecomboBox
            // 
            this.ItemnamecomboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ItemnamecomboBox.FormattingEnabled = true;
            this.ItemnamecomboBox.Location = new System.Drawing.Point(6, 126);
            this.ItemnamecomboBox.Name = "ItemnamecomboBox";
            this.ItemnamecomboBox.Size = new System.Drawing.Size(218, 28);
            this.ItemnamecomboBox.TabIndex = 1;
            this.ItemnamecomboBox.SelectedIndexChanged += new System.EventHandler(this.ItemnamecomboBox_SelectedIndexChanged);
            // 
            // clientnametextBox
            // 
            this.clientnametextBox.Location = new System.Drawing.Point(138, 23);
            this.clientnametextBox.Name = "clientnametextBox";
            this.clientnametextBox.Size = new System.Drawing.Size(211, 26);
            this.clientnametextBox.TabIndex = 1;
            // 
            // UnitpricetextBox
            // 
            this.UnitpricetextBox.Location = new System.Drawing.Point(704, 120);
            this.UnitpricetextBox.Name = "UnitpricetextBox";
            this.UnitpricetextBox.ReadOnly = true;
            this.UnitpricetextBox.Size = new System.Drawing.Size(141, 26);
            this.UnitpricetextBox.TabIndex = 3;
            this.UnitpricetextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.UnitpricetextBox_KeyPress);
            // 
            // QuantitytextBox
            // 
            this.QuantitytextBox.Location = new System.Drawing.Point(527, 120);
            this.QuantitytextBox.Name = "QuantitytextBox";
            this.QuantitytextBox.Size = new System.Drawing.Size(145, 26);
            this.QuantitytextBox.TabIndex = 2;
            this.QuantitytextBox.TextChanged += new System.EventHandler(this.QuantitytextBox_TextChanged);
            this.QuantitytextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.QuantitytextBox_KeyPress);
            // 
            // UnitPriceLabel
            // 
            this.UnitPriceLabel.AutoSize = true;
            this.UnitPriceLabel.Location = new System.Drawing.Point(724, 76);
            this.UnitPriceLabel.Name = "UnitPriceLabel";
            this.UnitPriceLabel.Size = new System.Drawing.Size(87, 20);
            this.UnitPriceLabel.TabIndex = 3;
            this.UnitPriceLabel.Text = "Unit Price";
            // 
            // Quantitylabel
            // 
            this.Quantitylabel.AutoSize = true;
            this.Quantitylabel.Location = new System.Drawing.Point(559, 76);
            this.Quantitylabel.Name = "Quantitylabel";
            this.Quantitylabel.Size = new System.Drawing.Size(76, 20);
            this.Quantitylabel.TabIndex = 2;
            this.Quantitylabel.Text = "Quantity";
            // 
            // ItemNamelabel
            // 
            this.ItemNamelabel.AutoSize = true;
            this.ItemNamelabel.Location = new System.Drawing.Point(27, 93);
            this.ItemNamelabel.Name = "ItemNamelabel";
            this.ItemNamelabel.Size = new System.Drawing.Size(149, 20);
            this.ItemNamelabel.TabIndex = 1;
            this.ItemNamelabel.Text = "PRODUCT NAME";
            // 
            // clientnamelabel
            // 
            this.clientnamelabel.AutoSize = true;
            this.clientnamelabel.Location = new System.Drawing.Point(6, 26);
            this.clientnamelabel.Name = "clientnamelabel";
            this.clientnamelabel.Size = new System.Drawing.Size(126, 20);
            this.clientnamelabel.TabIndex = 0;
            this.clientnamelabel.Text = "CLIENT NAME";
            // 
            // NewOrderbutton
            // 
            this.NewOrderbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.NewOrderbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewOrderbutton.Location = new System.Drawing.Point(999, 8);
            this.NewOrderbutton.Name = "NewOrderbutton";
            this.NewOrderbutton.Size = new System.Drawing.Size(158, 37);
            this.NewOrderbutton.TabIndex = 5;
            this.NewOrderbutton.Text = "New Order";
            this.NewOrderbutton.UseVisualStyleBackColor = true;
            this.NewOrderbutton.Click += new System.EventHandler(this.NewOrderbutton_Click);
            // 
            // PrintOrderbutton
            // 
            this.PrintOrderbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.PrintOrderbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrintOrderbutton.Location = new System.Drawing.Point(999, 78);
            this.PrintOrderbutton.Name = "PrintOrderbutton";
            this.PrintOrderbutton.Size = new System.Drawing.Size(158, 55);
            this.PrintOrderbutton.TabIndex = 6;
            this.PrintOrderbutton.Text = "Print Order";
            this.PrintOrderbutton.UseVisualStyleBackColor = true;
            this.PrintOrderbutton.Click += new System.EventHandler(this.PrintOrderbutton_Click);
            // 
            // PrintPreviewbutton
            // 
            this.PrintPreviewbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.PrintPreviewbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrintPreviewbutton.Location = new System.Drawing.Point(999, 166);
            this.PrintPreviewbutton.Name = "PrintPreviewbutton";
            this.PrintPreviewbutton.Size = new System.Drawing.Size(149, 57);
            this.PrintPreviewbutton.TabIndex = 7;
            this.PrintPreviewbutton.Text = "Print Preview";
            this.PrintPreviewbutton.UseVisualStyleBackColor = true;
            this.PrintPreviewbutton.Click += new System.EventHandler(this.PrintPreviewbutton_Click);
            // 
            // CancelOrderbutton
            // 
            this.CancelOrderbutton.Enabled = false;
            this.CancelOrderbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.CancelOrderbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CancelOrderbutton.Location = new System.Drawing.Point(999, 239);
            this.CancelOrderbutton.Name = "CancelOrderbutton";
            this.CancelOrderbutton.Size = new System.Drawing.Size(149, 60);
            this.CancelOrderbutton.TabIndex = 8;
            this.CancelOrderbutton.Text = "Cancel Order";
            this.CancelOrderbutton.UseVisualStyleBackColor = true;
            this.CancelOrderbutton.Click += new System.EventHandler(this.CancelOrderbutton_Click);
            // 
            // CartdataGridView
            // 
            this.CartdataGridView.AllowUserToAddRows = false;
            this.CartdataGridView.AllowUserToDeleteRows = false;
            this.CartdataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.CartdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CartdataGridView.Location = new System.Drawing.Point(12, 239);
            this.CartdataGridView.Name = "CartdataGridView";
            this.CartdataGridView.ReadOnly = true;
            this.CartdataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.CartdataGridView.Size = new System.Drawing.Size(981, 215);
            this.CartdataGridView.TabIndex = 5;
            this.CartdataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.CartdataGridView_CellContentClick);
            this.CartdataGridView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.CartdataGridView_MouseDown);
            // 
            // TotalAmountlabel
            // 
            this.TotalAmountlabel.AutoSize = true;
            this.TotalAmountlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalAmountlabel.Location = new System.Drawing.Point(72, 507);
            this.TotalAmountlabel.Name = "TotalAmountlabel";
            this.TotalAmountlabel.Size = new System.Drawing.Size(116, 20);
            this.TotalAmountlabel.TabIndex = 6;
            this.TotalAmountlabel.Text = "Total Amount";
            // 
            // Salestaxlabel
            // 
            this.Salestaxlabel.AutoSize = true;
            this.Salestaxlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Salestaxlabel.Location = new System.Drawing.Point(392, 507);
            this.Salestaxlabel.Name = "Salestaxlabel";
            this.Salestaxlabel.Size = new System.Drawing.Size(92, 20);
            this.Salestaxlabel.TabIndex = 7;
            this.Salestaxlabel.Text = "Sales Tax:";
            // 
            // TotalToPaylabel
            // 
            this.TotalToPaylabel.AutoSize = true;
            this.TotalToPaylabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalToPaylabel.Location = new System.Drawing.Point(715, 513);
            this.TotalToPaylabel.Name = "TotalToPaylabel";
            this.TotalToPaylabel.Size = new System.Drawing.Size(108, 20);
            this.TotalToPaylabel.TabIndex = 8;
            this.TotalToPaylabel.Text = "Total To Pay";
            // 
            // TotalAmounttextBox
            // 
            this.TotalAmounttextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalAmounttextBox.Location = new System.Drawing.Point(206, 501);
            this.TotalAmounttextBox.Name = "TotalAmounttextBox";
            this.TotalAmounttextBox.ReadOnly = true;
            this.TotalAmounttextBox.Size = new System.Drawing.Size(138, 26);
            this.TotalAmounttextBox.TabIndex = 9;
            // 
            // SalesTaxtextBox
            // 
            this.SalesTaxtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalesTaxtextBox.Location = new System.Drawing.Point(539, 507);
            this.SalesTaxtextBox.Name = "SalesTaxtextBox";
            this.SalesTaxtextBox.ReadOnly = true;
            this.SalesTaxtextBox.Size = new System.Drawing.Size(138, 26);
            this.SalesTaxtextBox.TabIndex = 10;
            // 
            // TotalToPaytextBox
            // 
            this.TotalToPaytextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalToPaytextBox.Location = new System.Drawing.Point(855, 510);
            this.TotalToPaytextBox.Name = "TotalToPaytextBox";
            this.TotalToPaytextBox.ReadOnly = true;
            this.TotalToPaytextBox.Size = new System.Drawing.Size(138, 26);
            this.TotalToPaytextBox.TabIndex = 11;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(153, 48);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.deleteToolStripMenuItem.Text = "&Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // buttonCALC
            // 
            this.buttonCALC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonCALC.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCALC.Location = new System.Drawing.Point(999, 317);
            this.buttonCALC.Name = "buttonCALC";
            this.buttonCALC.Size = new System.Drawing.Size(149, 45);
            this.buttonCALC.TabIndex = 12;
            this.buttonCALC.Text = "CALCULATOR";
            this.buttonCALC.UseVisualStyleBackColor = true;
            this.buttonCALC.Click += new System.EventHandler(this.buttonCALC_Click);
            // 
            // RECEIPT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(1160, 572);
            this.Controls.Add(this.buttonCALC);
            this.Controls.Add(this.TotalToPaytextBox);
            this.Controls.Add(this.SalesTaxtextBox);
            this.Controls.Add(this.TotalAmounttextBox);
            this.Controls.Add(this.TotalToPaylabel);
            this.Controls.Add(this.Salestaxlabel);
            this.Controls.Add(this.TotalAmountlabel);
            this.Controls.Add(this.CartdataGridView);
            this.Controls.Add(this.CancelOrderbutton);
            this.Controls.Add(this.PrintPreviewbutton);
            this.Controls.Add(this.PrintOrderbutton);
            this.Controls.Add(this.NewOrderbutton);
            this.Controls.Add(this.ItemgroupBox);
            this.Name = "RECEIPT";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RECEIPT";
            this.ItemgroupBox.ResumeLayout(false);
            this.ItemgroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CartdataGridView)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void CartdataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.GroupBox ItemgroupBox;
        private System.Windows.Forms.Button AddTocartbutton;
        private System.Windows.Forms.ComboBox ItemnamecomboBox;
        private System.Windows.Forms.TextBox clientnametextBox;
        private System.Windows.Forms.TextBox UnitpricetextBox;
        private System.Windows.Forms.TextBox QuantitytextBox;
        private System.Windows.Forms.Label UnitPriceLabel;
        private System.Windows.Forms.Label Quantitylabel;
        private System.Windows.Forms.Label ItemNamelabel;
        private System.Windows.Forms.Label clientnamelabel;
        private System.Windows.Forms.Button NewOrderbutton;
        private System.Windows.Forms.Button PrintOrderbutton;
        private System.Windows.Forms.Button PrintPreviewbutton;
        private System.Windows.Forms.Button CancelOrderbutton;
        private System.Windows.Forms.DataGridView CartdataGridView;
        private System.Windows.Forms.Label TotalAmountlabel;
        private System.Windows.Forms.Label Salestaxlabel;
        private System.Windows.Forms.Label TotalToPaylabel;
        private System.Windows.Forms.TextBox TotalAmounttextBox;
        private System.Windows.Forms.TextBox SalesTaxtextBox;
        private System.Windows.Forms.TextBox TotalToPaytextBox;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private TextBox textBoxQtySale;
        private Label label2;
        private Button buttonCALC;
        private Label label1;
        private DateTimePicker dateTimePicker1;

        public EventHandler Salestaxlabel_Click { get; private set; }
        public EventHandler RECEIPT_Load { get; private set; }
    }
}