﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STOCK__MANAGEMENT_SYSTEM
{
    public partial class USER_MAIN_PAGE : Form
    {
        public USER_MAIN_PAGE()
        {
            InitializeComponent();
        }

        private void lOGOUTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 obj = new Form1();
            obj.Show();
        }

        private void rEPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //MANAGE_CUSTOMER obj = new MANAGE_CUSTOMER();
            //obj.Show();
        }

        private void mESSAGESToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ALERT_MESSAGE obj = new ALERT_MESSAGE();
            obj.Show();
        }

        private void mOREToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MORE obj = new MORE();
            obj.Show();
        }

        private void cONTACTSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CONTACTS obj = new CONTACTS();
            obj.Show();
        }

        private void mANAGEORDERSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RECEIPT obj = new RECEIPT();
            obj.Show();
        }

        private void mANGECUSTOMERToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //MANAGE_CUSTOMER obj = new MANAGE_CUSTOMER();
            //obj.Show();
        }

        private void mANAGEORDERSToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
           
        }

        private void mESSAGESToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            ALERT_MESSAGE obj = new ALERT_MESSAGE();
            obj.Show();
        }

        private void cONTACTSToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
           
        }

        private void mOREToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            CALCULATOR obj = new CALCULATOR();
            obj.Show();
        }

        private void lOGOUTToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Form1 obj = new Form1();
            obj.Show();
            this.Hide();

        }

        private void cALCULATORToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
           // this.Hide();
        }

        private void cONTACTSToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            CONTACTS obj = new CONTACTS();
            obj.Show();

        }

        private void mOREToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MORE obj = new MORE();
            obj.Show();

        }

        private void pRINTRECEIPTSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RECEIPT obj = new RECEIPT();
            obj.Show();
        }

        private void rETURNPRODUCTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //RETURN_PRODUCT obj = new RETURN_PRODUCT();
            //obj.Show();
            //this.Hide();
        }

        private void searchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void dELIVERYToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //DELIVERY obj = new DELIVERY();
            //obj.Show();
        }
    }
}
