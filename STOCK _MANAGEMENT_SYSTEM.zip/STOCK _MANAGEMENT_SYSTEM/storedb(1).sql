-- phpMyAdmin SQL Dump
-- version 3.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 24, 2018 at 05:43 PM
-- Server version: 5.5.25a
-- PHP Version: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `storedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `CateID` int(11) NOT NULL AUTO_INCREMENT,
  `category_Name` varchar(200) NOT NULL,
  PRIMARY KEY (`CateID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`CateID`, `category_Name`) VALUES
(1, 'phone'),
(2, 'clothes '),
(4, 'machinery'),
(5, 'computing'),
(6, 'laptops'),
(7, 'software '),
(8, 'books'),
(9, 'shoes'),
(10, 'painkillers');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE IF NOT EXISTS `history` (
  `activity` varchar(200) NOT NULL,
  `time` varchar(200) NOT NULL,
  `date` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`activity`, `time`, `date`) VALUES
('pallogged in ', '6:28 PM', '9/21/2017'),
('pallogged in ', '6:44 PM', '9/21/2017'),
('pallogged in ', '6:45 PM', '9/21/2017'),
('pallogged in ', '6:47 PM', '9/21/2017'),
('pallogged in ', '7:11 PM', '9/21/2017'),
('pallogged in ', '7:19 PM', '9/21/2017'),
('pallogged in ', '7:22 PM', '9/21/2017'),
('pallogged in ', '7:23 PM', '9/21/2017'),
('pallogged in ', '11:11 AM', '9/22/2017'),
('pallogged in ', '11:33 AM', '9/22/2017'),
('pallogged in ', '11:37 AM', '9/22/2017'),
('pallogged in ', '11:48 AM', '9/22/2017'),
('abclogged in ', '11:49 AM', '9/22/2017'),
('pallogged in ', '11:54 AM', '9/22/2017'),
('pallogged in ', '5:25 PM', '9/22/2017'),
('pallogged in ', '5:56 PM', '9/22/2017'),
('pallogged in ', '6:01 PM', '9/22/2017'),
('pallogged in ', '6:02 PM', '9/22/2017'),
('pallogged in ', '6:08 PM', '9/22/2017'),
('pallogged in ', '6:12 PM', '9/22/2017'),
('pallogged in ', '6:16 PM', '9/22/2017'),
('janelogged in ', '6:22 PM', '9/22/2017'),
('pallogged in ', '7:53 AM', '9/23/2017'),
('pallogged in ', '7:55 AM', '9/23/2017'),
('pallogged in ', '7:56 AM', '9/23/2017'),
('pallogged in ', '7:57 AM', '9/23/2017'),
('pallogged in ', '8:00 AM', '9/23/2017'),
('pallogged in ', '8:05 AM', '9/23/2017'),
('pallogged in ', '8:07 AM', '9/23/2017'),
('janelogged in ', '8:07 AM', '9/23/2017'),
('pallogged in ', '8:19 AM', '9/23/2017'),
('pallogged in ', '8:22 AM', '9/23/2017'),
('pallogged in ', '8:27 AM', '9/23/2017'),
('pallogged in ', '8:45 AM', '9/23/2017'),
('pallogged in ', '8:50 AM', '9/23/2017'),
('pallogged in ', '8:52 AM', '9/23/2017'),
('pallogged in ', '8:54 AM', '9/23/2017'),
('pallogged in ', '9:04 AM', '9/23/2017'),
('pallogged in ', '9:06 AM', '9/23/2017'),
('pallogged in ', '9:07 AM', '9/23/2017'),
('janelogged in ', '9:08 AM', '9/23/2017'),
('pallogged in ', '9:08 AM', '9/23/2017'),
('pallogged in ', '9:13 AM', '9/23/2017'),
('pallogged in ', '9:15 AM', '9/23/2017'),
('janelogged in ', '9:17 AM', '9/23/2017'),
('janelogged in ', '9:22 AM', '9/23/2017'),
('janelogged in ', '9:24 AM', '9/23/2017'),
('janelogged in ', '9:28 AM', '9/23/2017'),
('pallogged in ', '9:31 AM', '9/23/2017'),
('abclogged in ', '10:51 AM', '9/23/2017'),
('pallogged in ', '7:41 AM', '9/24/2017'),
('janelogged in ', '8:08 AM', '9/24/2017'),
('JANElogged in ', '8:14 AM', '9/24/2017'),
('pallogged in ', '8:18 AM', '9/24/2017'),
('pallogged in ', '8:22 AM', '9/24/2017'),
('pallogged in ', '8:23 AM', '9/24/2017'),
('pallogged in ', '8:24 AM', '9/24/2017'),
('pallogged in ', '8:25 AM', '9/24/2017'),
('pallogged in ', '8:31 AM', '9/24/2017'),
('pallogged in ', '8:32 AM', '9/24/2017'),
('pallogged in ', '8:35 AM', '9/24/2017'),
('pallogged in ', '1:52 PM', '9/25/2017'),
('pallogged in ', '1:55 PM', '9/25/2017'),
('pallogged in ', '1:57 PM', '9/25/2017'),
('pallogged in ', '2:01 PM', '9/25/2017'),
('pallogged in ', '2:02 PM', '9/25/2017'),
('pallogged in ', '2:03 PM', '9/25/2017'),
('pallogged in ', '9:13 AM', '11/16/2017'),
('pallogged in ', '9:15 AM', '11/16/2017'),
('adminwas added as a new user ', '9:16 AM', '11/16/2017'),
('palwas deleted from database ', '9:16 AM', '11/16/2017'),
('abcwas deleted from database ', '9:16 AM', '11/16/2017'),
('userwas added as a new user ', '9:17 AM', '11/16/2017'),
('adminlogged in ', '9:17 AM', '11/16/2017'),
('adminlogged in ', '9:31 AM', '11/16/2017'),
('userlogged in ', '9:32 AM', '11/16/2017'),
('ADMINlogged in ', '9:37 AM', '11/16/2017'),
('adminlogged in ', '9:39 AM', '11/16/2017'),
('adminlogged in ', '8:41 AM', '11/17/2017'),
('adminlogged in ', '4:30 PM', '1/10/2018'),
('userlogged in ', '9:38 PM', '1/12/2018'),
('adminlogged in ', '9:45 PM', '1/12/2018'),
('userlogged in ', '9:11 AM', '1/15/2018'),
('userlogged in ', '9:14 AM', '1/15/2018'),
('userlogged in ', '9:16 AM', '1/15/2018'),
('adminlogged in ', '9:17 AM', '1/15/2018'),
('adminlogged in ', '9:22 AM', '1/15/2018'),
('adminlogged in ', '9:34 AM', '1/15/2018'),
('userlogged in ', '9:40 AM', '1/15/2018'),
('adminlogged in ', '10:07 AM', '1/15/2018'),
('user1was added as a new user ', '10:10 AM', '1/15/2018'),
('user1was deleted from database ', '10:10 AM', '1/15/2018'),
('adminlogged in ', '2:26 PM', '1/15/2018'),
('userlogged in ', '2:39 PM', '1/15/2018'),
('adminlogged in ', '2:46 PM', '1/15/2018'),
('userlogged in ', '8:02 PM', '1/15/2018'),
('adminlogged in ', '8:04 PM', '1/15/2018'),
('adminlogged in ', '8:06 PM', '1/15/2018'),
('adminlogged in ', '8:11 PM', '1/15/2018'),
('adminlogged in ', '8:14 PM', '1/15/2018'),
('adminlogged in ', '6:19 AM', '1/16/2018'),
('adminlogged in ', '7:05 AM', '1/16/2018'),
('adminlogged in ', '7:12 AM', '1/16/2018'),
('adminlogged in ', '7:22 AM', '1/16/2018'),
('adminlogged in ', '7:24 AM', '1/16/2018'),
('adminlogged in ', '7:34 AM', '1/16/2018'),
('adminlogged in ', '7:37 AM', '1/16/2018'),
('adminlogged in ', '7:37 AM', '1/16/2018'),
('adminlogged in ', '7:46 AM', '1/16/2018'),
('adminlogged in ', '4:29 PM', '1/16/2018'),
('adminlogged in ', '4:46 PM', '1/16/2018'),
('adminlogged in ', '5:29 PM', '1/16/2018'),
('adminlogged in ', '5:30 PM', '1/16/2018'),
('adminlogged in ', '5:34 PM', '1/16/2018'),
('adminlogged in ', '5:37 PM', '1/16/2018'),
('adminlogged in ', '5:50 PM', '1/16/2018'),
('adminlogged in ', '5:51 PM', '1/16/2018'),
('adminlogged in ', '6:21 PM', '1/16/2018'),
('adminlogged in ', '6:36 PM', '1/16/2018'),
('adminlogged in ', '6:40 PM', '1/16/2018'),
('adminlogged in ', '6:42 PM', '1/16/2018'),
('adminlogged in ', '6:47 PM', '1/16/2018'),
('adminlogged in ', '6:49 PM', '1/16/2018'),
('adminlogged in ', '6:50 PM', '1/16/2018'),
('adminlogged in ', '6:52 PM', '1/16/2018'),
('adminlogged in ', '6:58 PM', '1/16/2018'),
('adminlogged in ', '7:30 PM', '1/16/2018'),
('adminlogged in ', '9:26 PM', '1/17/2018'),
('adminlogged in ', '9:34 PM', '1/17/2018'),
('adminlogged in ', '10:04 PM', '1/17/2018'),
('adminlogged in ', '10:10 PM', '1/17/2018'),
('adminlogged in ', '10:16 PM', '1/17/2018'),
('adminlogged in ', '10:28 PM', '1/17/2018'),
('adminlogged in ', '10:31 PM', '1/17/2018'),
('adminlogged in ', '10:32 PM', '1/17/2018'),
('adminlogged in ', '10:32 PM', '1/17/2018'),
('adminlogged in ', '10:33 PM', '1/17/2018'),
('palwas added as a new user ', '10:36 PM', '1/17/2018'),
('palwas deleted from database ', '10:36 PM', '1/17/2018'),
('adminlogged in ', '10:58 PM', '1/17/2018'),
('adminlogged in ', '10:59 PM', '1/17/2018'),
('adminlogged in ', '11:01 PM', '1/17/2018'),
('adminlogged in ', '11:10 PM', '1/17/2018'),
('adminlogged in ', '11:15 PM', '1/17/2018'),
('adminlogged in ', '11:17 PM', '1/17/2018'),
('adminlogged in ', '11:18 PM', '1/17/2018'),
('adminlogged in ', '11:23 PM', '1/17/2018'),
('adminlogged in ', '11:27 PM', '1/17/2018'),
('adminlogged in ', '11:28 PM', '1/17/2018'),
('adminlogged in ', '11:30 PM', '1/17/2018'),
('adminlogged in ', '11:35 PM', '1/17/2018'),
('adminlogged in ', '11:38 PM', '1/17/2018'),
('adminlogged in ', '11:41 PM', '1/17/2018'),
('userlogged in ', '11:43 PM', '1/17/2018'),
('adminlogged in ', '6:06 AM', '1/18/2018'),
('adminlogged in ', '6:12 AM', '1/18/2018'),
('adminlogged in ', '6:15 AM', '1/18/2018'),
('adminlogged in ', '6:18 AM', '1/18/2018'),
('adminlogged in ', '6:22 AM', '1/18/2018'),
('adminlogged in ', '6:25 AM', '1/18/2018'),
('adminlogged in ', '6:26 AM', '1/18/2018'),
('adminlogged in ', '6:27 AM', '1/18/2018'),
('adminlogged in ', '6:28 AM', '1/18/2018'),
('adminlogged in ', '6:31 AM', '1/18/2018'),
('adminlogged in ', '6:33 AM', '1/18/2018'),
('adminlogged in ', '6:34 AM', '1/18/2018'),
('adminlogged in ', '6:36 AM', '1/18/2018'),
('adminlogged in ', '6:37 AM', '1/18/2018'),
('adminlogged in ', '6:39 AM', '1/18/2018'),
('adminlogged in ', '7:28 AM', '1/18/2018'),
('adminlogged in ', '9:22 AM', '2/19/2018'),
('adminlogged in ', '10:29 AM', '3/1/2018'),
('userlogged in ', '10:31 AM', '3/1/2018'),
('adminlogged in ', '9:37 AM', '3/13/2018'),
('adminlogged in ', '12:20 PM', '3/13/2018'),
('adminlogged in ', '12:25 PM', '3/13/2018'),
('adminlogged in ', '10:58 AM', '5/15/2018'),
('adminlogged in ', '11:24 AM', '5/15/2018'),
('adminlogged in ', '11:34 AM', '5/15/2018'),
('adminlogged in ', '11:42 AM', '5/15/2018'),
('adminlogged in ', '11:58 AM', '5/15/2018'),
('userlogged in ', '11:58 AM', '5/15/2018'),
('adminlogged in ', '8:03 AM', '7/13/2018'),
('adminlogged in ', '8:21 AM', '7/13/2018');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('admin', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE IF NOT EXISTS `report` (
  `Product_Name` varchar(50) NOT NULL,
  `Quantity_Sold` varchar(50) NOT NULL,
  `Unit_Price` varchar(50) NOT NULL,
  `Total_Price` varchar(50) NOT NULL,
  `TotalAmountPaid` varchar(50) NOT NULL,
  `Date_of_Sale` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`Product_Name`, `Quantity_Sold`, `Unit_Price`, `Total_Price`, `TotalAmountPaid`, `Date_of_Sale`) VALUES
('jembe', '3', '700', '2100', '53476', 'Wednesday, January 17, 2018'),
('injoo ', '5', '8000', '40000', '53476', 'Wednesday, January 17, 2018'),
('mouse', '8', '500', '4000', '53476', 'Wednesday, January 17, 2018'),
('injoo ', '10', '8000', '80000', '92800', 'Wednesday, January 17, 2018'),
('sony ', '10', '45000', '450000', '522000', 'Thursday, January 18, 2018'),
('sony ', '1', '45000', '45000', '52200', 'Thursday, January 18, 2018');

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE IF NOT EXISTS `section` (
  `section_id` int(11) NOT NULL AUTO_INCREMENT,
  `section_name` varchar(50) NOT NULL,
  PRIMARY KEY (`section_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `section`
--

INSERT INTO `section` (`section_id`, `section_name`) VALUES
(10, 'A'),
(11, 'E'),
(12, 'C'),
(13, 'B'),
(14, 'D'),
(15, 'F'),
(16, 'G');

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE IF NOT EXISTS `store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proname` varchar(200) NOT NULL,
  `catename` varchar(200) NOT NULL,
  `stock` int(200) NOT NULL,
  `price` varchar(200) NOT NULL,
  `date` varchar(200) NOT NULL,
  `alert` varchar(200) NOT NULL,
  `description` varchar(200) NOT NULL,
  `section` varchar(200) NOT NULL,
  `Supplier_Id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`id`, `proname`, `catename`, `stock`, `price`, `date`, `alert`, `description`, `section`, `Supplier_Id`) VALUES
(12, 'sony  ', 'laptops', 17, '45000', 'Wednesday, January 17, 2018', '3', 'valcao', 'D', 5),
(13, 'injoo ', 'phone', 30, '8000', 'Wednesday, January 17, 2018', '2', 'gold', 'G', 6),
(14, 'mouse', 'computing', 82, '500', 'Wednesday, January 17, 2018', '12', 'hp black', 'F', 4),
(15, 'jembe', 'machinery', 12, '700', 'Wednesday, January 17, 2018', '2', 'metallic', 'G', 4),
(16, 'Usb flash ', 'computing', 13, '500', 'Thursday, January 18, 2018', '3', '8gb', 'B', 6),
(17, 'KMSauto', 'software ', 23, '200', 'Thursday, January 18, 2018', '5', 'japane model', 'C', 5);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE IF NOT EXISTS `suppliers` (
  `Supplier_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Supplier_Name` varchar(200) NOT NULL,
  `Company_Name` varchar(200) NOT NULL,
  `Phone` varchar(200) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Account` varchar(200) NOT NULL,
  PRIMARY KEY (`Supplier_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`Supplier_ID`, `Supplier_Name`, `Company_Name`, `Phone`, `Address`, `Account`) VALUES
(4, 'puma', 'puma limited', '0712345789', 'pumaclothes@gmail.com', '987654320000'),
(5, 'techo', 'ibm', 'ibm@techo', '0712356890', '000098885467'),
(6, 'sumsung ', 'galaxy', '0717537477', 'galaxy@sum.com', '456700023456');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usertype` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `usertype`, `username`, `password`) VALUES
(11, 'USER', 'user', '1234'),
(14, 'ADMIN', 'admin', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(2, 'admin', '1234'),
(9, 'username', '0717537477'),
(10, '', ''),
(11, '', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
